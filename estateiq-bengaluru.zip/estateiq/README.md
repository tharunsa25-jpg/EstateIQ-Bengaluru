# EstateIQ – Bengaluru Smart Property Price Prediction System

**Bengaluru (Karnataka, India) property price prediction with Multiple Linear Regression** · Machine Learning academic mini project

React + Tailwind + Recharts + Leaflet/OpenStreetMap frontend · Flask backend · scikit-learn `LinearRegression` · Pandas/NumPy · Joblib · SQLite · all prices in Indian Rupees (₹)

## What it does
Landing page, Prediction Studio, result dashboard (feature contributions, comparison, PDF report, save to history), **Bengaluru locality analytics**, **interactive Bengaluru map**, Model Intelligence Center, Comparison Lab, History, Insights and About. Every price, metric, chart and insight is computed from the dataset or from the trained model. Nothing is random or hard-coded.

## Dataset
`backend/dataset/Bengaluru_House_Data.csv`: public **"Bengaluru House Price Data"** (Kaggle), 13,320 property **listings** with `location`, `area_type`, `availability`, `size` (BHK), `total_sqft`, `bath`, `balcony`, and `price` in **lakh rupees**. `train_model.py` downloads it from GitHub if the file is missing.

- **Target is natively INR.** Price is multiplied by 1,00,000 (a unit change from lakh to rupees; no currency conversion is involved).
- **These are listing (asking) prices from an undated historic snapshot, not transaction prices and not live market data.** EstateIQ is not connected to any live data source and never claims live prices.
- **Cleaning** (documented in `train_model.py`): area text such as `2100 - 2850` is averaged and other units converted to sq.ft; rows without area/price, under 300 sq.ft per bedroom, with implausible bathroom counts or extreme ₹/sq.ft outliers are dropped (13,320 → 12,433 rows); missing bathrooms/balconies/BHK are median-imputed (fitted on the training split only).
- **Locality encoding:** the dataset's ~1,300 free-text locations are mapped onto your 34 requested localities by the rules in `backend/localities.py`; all other rows are grouped as "Other Bengaluru" for training, and `locality` is one-hot encoded.

### Honest limitations
- **3 of the 34 requested localities cannot be priced:** *MG Road* (1 listing), *Peenya* (10) and *Kadubeesanahalli* (13) have fewer than 15 listings. They appear in the dropdown (disabled, with the reason) and on the map (hollow marker), and the API refuses them instead of inventing a price. Localities with under 40 listings (e.g. Arekere, Frazer Town, Sahakara Nagar, Vijayanagar, Basaveshwaranagar) are flagged **limited data**.
- **Floors, property age, parking and property type are not columns in this dataset**, so the model cannot learn their effect. The form still collects them (under "Additional details, recorded but not used for pricing"); they are saved with the prediction and printed in the PDF but **do not change the estimated price**. Real model inputs: locality, area, BHK, bathrooms, balconies, possession (ready to move or not) and area basis (super built-up / built-up / plot / carpet).
- Locality comparisons use the model's estimate for the dataset's own **median home** (1,300 sq.ft, 3 BHK, 2 bath, 2 balconies, ready to move) so localities compare fairly. They are model estimates, not market quotes.
- Map marker positions are approximate locality centres (no price information).

## Model & ML rules followed
Clean → **80/20 split first** → imputer + one-hot encoder fitted on **train only** (no leakage) → `LinearRegression` → evaluate on test (R², MAE, MSE, RMSE) → save with Joblib. Latest run (test set): **R² ≈ 0.68, MAE ≈ ₹33.7 lakh, RMSE ≈ ₹73.96 lakh** (train R² 0.67, so no overfitting). Exact numbers are always read from `backend/model/metrics.json`. Linear regression is a modest model for skewed listing prices; expect larger errors for expensive homes.
The price range shown is the 10th–90th percentile of held-out test residuals, not a guaranteed confidence interval. If the linear model's output for an extreme input combination falls below ₹10 lakh, the API returns an error instead of a meaningless number.

## Folder structure
```
estateiq/
├── backend/
│   ├── app.py              Flask API (predict, compare, curve, analytics, model, insights, history)
│   ├── train_model.py      cleaning + training + evaluation + analytics export
│   ├── localities.py       the 34 localities, zones, map coordinates, matching rules
│   ├── requirements.txt
│   ├── dataset/Bengaluru_House_Data.csv
│   └── model/              model.joblib, metrics.json, model_params.json, analytics.json
└── frontend/               React + Vite + Tailwind + Recharts + Leaflet
```

## Run in VS Code (step by step)
Prerequisites: **Python 3.10+** and **Node.js 18+**.

1. Open the `estateiq` folder in VS Code (*File → Open Folder*). Open a terminal (*Terminal → New Terminal*) and split it into two.
2. **Backend (terminal 1)**
   ```bash
   cd backend
   python -m venv venv
   venv\Scripts\activate          # Windows   |   source venv/bin/activate   # macOS/Linux
   pip install -r requirements.txt
   python train_model.py          # trains on the Bengaluru data, prints metrics, writes backend/model/*
   python app.py                  # API on http://localhost:5000
   ```
   (A trained model is included, so `train_model.py` is optional the first time, but run it to show the training in your demo.)
3. **Frontend (terminal 2)**
   ```bash
   cd frontend
   npm install
   npm run dev                    # http://localhost:5173  (proxies /api to Flask)
   ```
4. Open **http://localhost:5173**. Sanity check: http://localhost:5000/api/health returns `{"city":"Bengaluru","status":"ok",...}`.

The map uses OpenStreetMap tiles, so it needs internet access in the browser to show street tiles.

### Serverless demo build (optional)
`npm run build:demo` produces one self-contained `dist-demo/index.html` that evaluates the **same trained coefficients** in the browser (history in localStorage), handy for sharing without a server. The real project uses Flask + joblib + SQLite.

## API
| Method | Route | Purpose |
|---|---|---|
| POST | `/api/predict` | validate → model prediction, ₹/sq.ft, residual range, feature contributions |
| POST | `/api/compare` | 2–3 properties |
| POST | `/api/curve` | predicted price across areas (Area vs Predicted Price chart) |
| GET | `/api/meta` `/api/analytics` `/api/model` `/api/insights` | dataset-derived data |
| GET/POST/DELETE | `/api/history`, `/api/history/<id>` | SQLite prediction history |

## Troubleshooting
- *"Cannot reach the EstateIQ backend"* → Flask isn't running (step 2) or port 5000 is busy (macOS AirPlay uses 5000: change the port in `app.py` and `vite.config.js`).
- *"Model not found"* → run `python train_model.py`.
- PowerShell blocks venv activation → `Set-ExecutionPolicy -Scope Process Bypass`.

## Viva cheat-sheet
Linear regression fits `Price = b0 + b1·x1 + … + bn·xn` by minimising squared error (OLS). R² = share of price variance explained on unseen data; MAE = average rupee error; RMSE penalises large errors more. Limitations: assumes linear additive effects, listing prices rather than sale prices, historic data, thin data for some localities. Future work: log-price, Ridge/Lasso, gradient boosting, fresher data with property age/parking/type, a verified live source.
