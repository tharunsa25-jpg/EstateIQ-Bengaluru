"""EstateIQ Bengaluru - Flask API: serves the trained Linear Regression model, dataset analytics and prediction history."""
import json, os, sqlite3
from datetime import datetime, timezone

import joblib, pandas as pd
from flask import Flask, g, jsonify, request
from flask_cors import CORS

from localities import LOCALITIES, ZONES

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE, "model")
DB_PATH = os.path.join(BASE, "history_blr.db")

app = Flask(__name__)
CORS(app)
if not os.path.exists(os.path.join(MODEL_DIR, "model.joblib")):
    raise SystemExit("Model not found. Run `python train_model.py` first.")

MODEL = joblib.load(os.path.join(MODEL_DIR, "model.joblib"))
_load = lambda n: json.load(open(os.path.join(MODEL_DIR, n), encoding="utf-8"))
PARAMS, ANALYTICS, METRICS = _load("model_params.json"), _load("analytics.json"), _load("metrics.json")
LOCS = {l["name"]: l for l in ANALYTICS["localities"]}
ZONE_STATS = {z["zone"]: z for z in ANALYTICS["zones"]}
AREA_TYPES = ANALYTICS["dataset"]["area_types"]
NUMERIC = PARAMS["numeric_features"]          # total_sqft, bhk, bath, balcony, ready_to_move
LABELS = {"total_sqft": "Area", "bhk": "Bedrooms (BHK)", "bath": "Bathrooms", "balcony": "Balconies", "ready_to_move": "Ready to move",
          "locality": "Locality", "area_type": "Area basis"}
LIMITS = {"total_sqft": (300, 12000), "bhk": (1, 10), "bath": (1, 10), "balcony": (0, 5), "ready_to_move": (0, 1)}
PARKING = ["No parking", "1 car", "2 cars", "3+ cars"]
PROPERTY_TYPES = ["Apartment", "Independent House", "Villa"]
CURRENCY_NOTE = ("Estimate in Indian Rupees (₹) from a Linear Regression model trained on a historic snapshot of Bengaluru property LISTING "
                 "prices (not transaction prices, not live market data). Not a valuation; accuracy depends on dataset quality and age.")


def validate(p):
    """-> (model_inputs, extras, errors)"""
    clean, extras, errors = {}, {}, {}
    loc = p.get("locality")
    if loc not in LOCS:
        errors["locality"] = "Choose a locality from the list."
    elif not LOCS[loc]["supported"]:
        errors["locality"] = (f"{loc} has only {LOCS[loc]['n_raw']} listing(s) in the dataset (minimum {ANALYTICS['dataset']['min_rows_supported']}), "
                              "so the model cannot give a reliable estimate for it. Pick another locality.")
    else:
        clean["locality"] = loc
    if p.get("area_type") not in AREA_TYPES:
        errors["area_type"] = "Choose an area basis."
    else:
        clean["area_type"] = p["area_type"]
    for f, (lo, hi) in LIMITS.items():
        try:
            v = float(p.get(f))
            if v != v or v < lo or v > hi:
                raise ValueError
            clean[f] = v
        except (TypeError, ValueError):
            errors[f] = f"{LABELS[f]} must be a number between {lo:g} and {hi:g}."
    # descriptive extras: accepted and reported, never used by the model (the dataset has no such columns)
    try:
        extras["floors"] = int(float(p.get("floors", 1)))
        extras["age"] = int(float(p.get("age", 0)))
        if not (1 <= extras["floors"] <= 60): raise ValueError
        if not (0 <= extras["age"] <= 100): raise ValueError
    except (TypeError, ValueError):
        errors["floors"] = "Floors must be 1–60 and age 0–100 years."
    extras["parking"] = p.get("parking", PARKING[0]) if p.get("parking", PARKING[0]) in PARKING else PARKING[0]
    extras["property_type"] = p.get("property_type", PROPERTY_TYPES[0]) if p.get("property_type", PROPERTY_TYPES[0]) in PROPERTY_TYPES else PROPERTY_TYPES[0]
    return clean, extras, errors


def _row(x):
    return {f: x[f] for f in NUMERIC + ["locality", "area_type"]}


def explain(x):
    out = []
    for f in NUMERIC:
        out.append({"feature": f, "label": LABELS[f], "value": x[f], "contribution": PARAMS["numeric_coefs"][f] * (x[f] - PARAMS["numeric_means"][f])})
    for f in ("locality", "area_type"):
        out.append({"feature": f, "label": LABELS[f], "value": x[f], "contribution": PARAMS["cat_coefs"][f][x[f]] - PARAMS["cat_mean_effect"][f]})
    return sorted(out, key=lambda c: -abs(c["contribution"]))


MIN_PRICE = 1_000_000   # ₹10 lakh: below this a linear model's output is extrapolation noise, not a usable estimate


class PriceOutOfRange(Exception):
    message = ("For this combination of area, BHK and bathrooms the linear model's estimate falls below ₹10 lakh, "
               "which is outside the range it can price reliably. Try a larger area or fewer bedrooms/bathrooms.")


@app.errorhandler(PriceOutOfRange)
def _out_of_range(e):
    return jsonify(error=e.message, fields={"total_sqft": e.message}), 400


def run_prediction(x, extras=None):
    price = float(MODEL.predict(pd.DataFrame([_row(x)]))[0])
    if price < MIN_PRICE:
        raise PriceOutOfRange()
    lo, hi = max(price + METRICS["residual_p10"], 0.0), max(price + METRICS["residual_p90"], 0.0)
    L = LOCS[x["locality"]]
    comp = [{"name": "This property", "value": price}, {"name": f"{L['name']} avg listing", "value": L["avg_price"]},
            {"name": f"{L['zone']} Bengaluru est.", "value": ZONE_STATS[L["zone"]]["est_price"]}, {"name": "Bengaluru median listing", "value": ANALYTICS["dataset"]["price_median"]}]
    return {"price": price, "price_per_sqft": price / x["total_sqft"], "price_per_sqft_unit": "₹/sq.ft", "currency": "INR",
            "range": {"low": lo, "high": hi, "note": "Estimate from the 10th–90th percentile of the model's held-out test residuals, not a guaranteed confidence interval."},
            "contributions": explain(x), "baseline": PARAMS["baseline"], "comparison": comp,
            "location_label": f"{L['name']}, Bengaluru, Karnataka, India", "zone": L["zone"], "locality_data_level": L["data_level"], "locality_n": L["n_listings"],
            "inputs": x, "extras": extras or {}, "disclaimer": CURRENCY_NOTE}


# ------------------------------------------------------------------ sqlite history
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH); g.db.row_factory = sqlite3.Row
        g.db.execute("CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, inputs TEXT, result TEXT)")
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d is not None:
        d.close()


def row_to_dict(r):
    inputs = json.loads(r["inputs"]); x, extras, errs = validate(inputs)
    result = run_prediction(x, extras) if not errs else json.loads(r["result"])
    return {"id": r["id"], "created_at": r["created_at"], "inputs": inputs, "result": result}


# ------------------------------------------------------------------ routes
@app.get("/api/health")
def health():
    return jsonify(status="ok", model="LinearRegression", city="Bengaluru", r2=METRICS["r2"])


@app.get("/api/meta")
def meta():
    return jsonify(ranges=ANALYTICS["ranges"], limits=LIMITS, dataset=ANALYTICS["dataset"], localities=ANALYTICS["localities"], zones=ZONES,
                   area_types=AREA_TYPES, parking=PARKING, property_types=PROPERTY_TYPES)


@app.post("/api/predict")
def predict():
    x, extras, errors = validate(request.get_json(silent=True) or {})
    if errors:
        return jsonify(error="Validation failed", fields=errors), 400
    return jsonify(run_prediction(x, extras))


@app.post("/api/compare")
def compare():
    items = (request.get_json(silent=True) or {}).get("properties", [])
    if not 2 <= len(items) <= 3:
        return jsonify(error="Provide 2 or 3 properties."), 400
    results, errs = [], {}
    for i, p in enumerate(items):
        x, extras, e = validate(p)
        if e:
            errs[i] = e
        else:
            results.append(run_prediction(x, extras))
    if errs:
        return jsonify(error="Validation failed", properties=errs), 400
    return jsonify(results=results)


@app.post("/api/curve")
def curve():
    """Predicted price across a range of areas for one property configuration (Area vs Predicted Price chart)."""
    x, _, errors = validate(request.get_json(silent=True) or {})
    if errors:
        return jsonify(error="Validation failed", fields=errors), 400
    areas = list(range(400, 4001, 200))
    rows = pd.DataFrame([{**_row(x), "total_sqft": a} for a in areas])
    return jsonify(points=[{"x": a, "y": float(p)} for a, p in zip(areas, MODEL.predict(rows))])


@app.get("/api/analytics")
def analytics():
    keys = ["scatter_area_price", "actual_vs_predicted", "bhk_avg", "bath_avg", "area_type_avg", "ready_avg", "histogram", "dataset",
            "localities", "zones", "highlights", "locality_points"]
    return jsonify({k: ANALYTICS[k] for k in keys})


@app.get("/api/model")
def model_info():
    return jsonify(dataset=ANALYTICS["dataset"], metrics=METRICS, equation=ANALYTICS["equation"], regression_line=ANALYTICS["regression_line"],
                   actual_vs_predicted=ANALYTICS["actual_vs_predicted"], scatter_area_price=ANALYTICS["scatter_area_price"], ranges=ANALYTICS["ranges"], labels=LABELS)


@app.get("/api/insights")
def insights():
    return jsonify(insights=ANALYTICS["insights"], correlations=ANALYTICS["correlations"], dataset=ANALYTICS["dataset"])


@app.get("/api/history")
def history_list():
    return jsonify([row_to_dict(r) for r in db().execute("SELECT * FROM history ORDER BY id DESC").fetchall()])


@app.post("/api/history")
def history_add():
    body = request.get_json(silent=True) or {}
    inputs = body.get("inputs", {})
    x, extras, errors = validate(inputs)
    if errors:
        return jsonify(error="Validation failed", fields=errors), 400
    result = run_prediction(x, extras)          # always recomputed server-side: never trust client-supplied prices
    cur = db().execute("INSERT INTO history (created_at, inputs, result) VALUES (?,?,?)",
                       (datetime.now(timezone.utc).isoformat(), json.dumps({**x, **extras}), json.dumps(result)))
    db().commit()
    return jsonify(row_to_dict(db().execute("SELECT * FROM history WHERE id=?", (cur.lastrowid,)).fetchone())), 201


@app.get("/api/history/<int:hid>")
def history_get(hid):
    r = db().execute("SELECT * FROM history WHERE id=?", (hid,)).fetchone()
    return jsonify(row_to_dict(r)) if r else (jsonify(error="Not found"), 404)


@app.delete("/api/history/<int:hid>")
def history_delete(hid):
    db().execute("DELETE FROM history WHERE id=?", (hid,)); db().commit()
    return jsonify(ok=True)


@app.delete("/api/history")
def history_clear():
    db().execute("DELETE FROM history"); db().commit()
    return jsonify(ok=True)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
