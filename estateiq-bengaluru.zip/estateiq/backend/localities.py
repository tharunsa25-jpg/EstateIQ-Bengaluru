"""Bengaluru locality configuration (labels, zones, approximate map coordinates) and the rules that map the
free-text `location` column of the dataset onto them.  Coordinates are approximate locality centres used ONLY
to place map markers - they carry no price information."""
import re

# name: (zone, lat, lng)
LOCALITIES = {
    # North
    "Yelahanka": ("North", 13.1007, 77.5963), "Hebbal": ("North", 13.0358, 77.5970), "Jakkur": ("North", 13.0785, 77.6070),
    "Thanisandra": ("North", 13.0548, 77.6370), "Hennur": ("North", 13.0430, 77.6420), "Devanahalli": ("North", 13.2480, 77.7130),
    "Sahakara Nagar": ("North", 13.0630, 77.5850),
    # South
    "Electronic City": ("South", 12.8452, 77.6602), "JP Nagar": ("South", 12.9063, 77.5857), "BTM Layout": ("South", 12.9166, 77.6101),
    "Bannerghatta Road": ("South", 12.8930, 77.5970), "Arekere": ("South", 12.8890, 77.6040), "Kanakapura Road": ("South", 12.8780, 77.5600),
    "Uttarahalli": ("South", 12.9020, 77.5430),
    # East
    "Whitefield": ("East", 12.9698, 77.7500), "Marathahalli": ("East", 12.9569, 77.7011), "Brookefield": ("East", 12.9660, 77.7180),
    "Varthur": ("East", 12.9390, 77.7410), "Sarjapur Road": ("East", 12.9100, 77.6870), "Bellandur": ("East", 12.9260, 77.6760),
    "Kadubeesanahalli": ("East", 12.9380, 77.6970),
    # West
    "Rajajinagar": ("West", 12.9910, 77.5550), "Vijayanagar": ("West", 12.9719, 77.5300), "Nagarbhavi": ("West", 12.9600, 77.5100),
    "Kengeri": ("West", 12.9170, 77.4830), "Basaveshwaranagar": ("West", 12.9890, 77.5380), "Peenya": ("West", 13.0285, 77.5197),
    # Central
    "Indiranagar": ("Central", 12.9784, 77.6408), "Koramangala": ("Central", 12.9352, 77.6245), "MG Road": ("Central", 12.9757, 77.6068),
    "Jayanagar": ("Central", 12.9250, 77.5938), "Malleshwaram": ("Central", 13.0035, 77.5710), "Frazer Town": ("Central", 12.9985, 77.6130),
    "CV Raman Nagar": ("Central", 12.9850, 77.6640),
}
ZONES = ["North", "South", "East", "West", "Central"]
OTHER = "Other Bengaluru"

# regex rules (checked in order) on the lower-cased location text; first match wins
_RULES = [
    ("Basaveshwaranagar", r"basaveshwar|basaveswar|basaveshwara"),
    ("Jakkur", r"jakkur"), ("Yelahanka", r"yelahanka"), ("Hebbal", r"hebbal"), ("Thanisandra", r"thanisandra"),
    ("Hennur", r"hennur"), ("Devanahalli", r"(^|[^a-z])devanahalli"), ("Sahakara Nagar", r"sahakara\s*nagar"),
    ("Electronic City", r"electronic"), ("JP Nagar", r"j\.?\s?p\.?\s*nagar"), ("BTM Layout", r"btm"),
    ("Bannerghatta Road", r"banner?gh?atta"), ("Arekere", r"(^|[^a-z])arekere"), ("Kanakapura Road", r"kanakapura"),
    ("Uttarahalli", r"uttarahalli"), ("Whitefield", r"white\s?fi[el]+d"), ("Marathahalli", r"marath+ahalli|marathalli"),
    ("Brookefield", r"brookefield"), ("Varthur", r"varthur"), ("Sarjapur Road", r"sarjapur"), ("Bellandur", r"bellandur"),
    ("Kadubeesanahalli", r"kadubeesanahalli"), ("Rajajinagar", r"rajaji\s*nagar"), ("Vijayanagar", r"(^|[^a-z])vijaya\s?nagar"),
    ("Nagarbhavi", r"nagarbhavi"), ("Kengeri", r"kengeri"), ("Peenya", r"peenya"), ("Indiranagar", r"indira\s?nagar"),
    ("Koramangala", r"koramangala"), ("MG Road", r"m\.?\s?g\.?\s*road"), ("Jayanagar", r"(^|[^a-z])jayanagar"),
    ("Malleshwaram", r"malleshwaram"), ("Frazer Town", r"frazer\s?town"), ("CV Raman Nagar", r"c\.?\s?v\.?\s*raman"),
]
_COMPILED = [(n, re.compile(p)) for n, p in _RULES]
assert {n for n, _ in _RULES} == set(LOCALITIES), "every configured locality needs a matching rule"


def canonical(location):
    if not isinstance(location, str):
        return OTHER
    t = location.lower().strip()
    for name, rx in _COMPILED:
        if rx.search(t):
            return name
    return OTHER
