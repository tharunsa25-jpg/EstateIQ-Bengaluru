"""
EstateIQ Bengaluru - model training script
==========================================
Trains a Multiple Linear Regression model (scikit-learn) on the public "Bengaluru House Data" set
(dataset/Bengaluru_House_Data.csv, 13,320 property listings; Kaggle: "Bengaluru House Price Data").

* Target  : price, in INR.  The dataset stores price in LAKHS of rupees, so it is multiplied by 100,000
            (a unit conversion, NOT a currency conversion - the data is natively Indian).
* Features: total_sqft, bhk, bath, balcony, ready_to_move, area_type (one-hot), locality (one-hot)
* No data leakage: the 80/20 split happens first; imputers/encoders are fitted on the TRAIN split only.

Run:  python train_model.py
Outputs (backend/model/): model.joblib, metrics.json, model_params.json, analytics.json
"""
import json, os, re, sys, urllib.request
import joblib, numpy as np, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from localities import LOCALITIES, ZONES, OTHER, canonical

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE, "dataset", "Bengaluru_House_Data.csv")
MODEL_DIR = os.path.join(BASE, "model")
DATA_URL = "https://raw.githubusercontent.com/The-Ark-Knight/BangalorePricePrediction/master/Bengaluru_House_Data.csv"
RANDOM_STATE = 42
LAKH = 100_000
MIN_ROWS_SUPPORTED = 15       # a locality needs at least this many listings to be offered for prediction
MIN_ROWS_CONFIDENT = 40       # below this a locality is flagged "limited data"

NUMERIC = ["total_sqft", "bhk", "bath", "balcony"]
BINARY = ["ready_to_move"]
CATEGORICAL = ["locality", "area_type"]
AREA_TYPES = ["Super built-up Area", "Built-up Area", "Plot Area", "Carpet Area"]
FEATURES = NUMERIC + BINARY + CATEGORICAL


def load_dataset():
    if not os.path.exists(DATA_PATH):
        print("Dataset not found - downloading", DATA_URL)
        os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
        urllib.request.urlretrieve(DATA_URL, DATA_PATH)
    return pd.read_csv(DATA_PATH)


# ------------------------------------------------------------------ cleaning
_UNITS = {"sq. meter": 10.7639, "sq. yards": 9.0, "perch": 272.25, "acres": 43560.0, "cents": 435.6, "guntha": 1089.0, "grounds": 2400.0}


def parse_sqft(v):
    """'1056' -> 1056 | '2100 - 2850' -> 2475 | '34.46Sq. Meter' -> converted | unparseable -> NaN"""
    s = str(v).strip().lower()
    try:
        return float(s)
    except ValueError:
        pass
    m = re.fullmatch(r"([\d.]+)\s*-\s*([\d.]+)", s)
    if m:
        return (float(m.group(1)) + float(m.group(2))) / 2
    m = re.fullmatch(r"([\d.]+)\s*([a-z. ]+)", s)
    if m and m.group(2).strip() in _UNITS:
        return float(m.group(1)) * _UNITS[m.group(2).strip()]
    return np.nan


def clean(raw):
    df = raw.copy(); n0 = len(df); log = {"rows_raw": n0}
    df["total_sqft"] = df["total_sqft"].map(parse_sqft)
    df["bhk"] = pd.to_numeric(df["size"].astype(str).str.extract(r"(\d+)")[0], errors="coerce")
    df["area_type"] = df["area_type"].astype(str).str.replace(r"\s+", " ", regex=True).str.strip()
    df["ready_to_move"] = df["availability"].isin(["Ready To Move", "Immediate Possession"]).astype(int)
    df["locality"] = df["location"].map(canonical)
    df["price_inr"] = df["price"] * LAKH
    log["missing_before"] = {c: int(df[c].isna().sum()) for c in ["bath", "balcony", "bhk", "total_sqft"]}
    df = df.dropna(subset=["total_sqft", "price_inr"])              # a listing without area or price is unusable
    df = df[df["bhk"].between(1, 10) | df["bhk"].isna()]
    df = df[(df["total_sqft"] / df["bhk"].fillna(2)) >= 300]        # <300 sqft per bedroom = data-entry error
    df = df[(df["bath"].isna()) | (df["bath"] <= df["bhk"].fillna(10) + 2)]
    ppsf = df["price_inr"] / df["total_sqft"]
    lo, hi = ppsf.quantile([0.005, 0.995]); df = df[ppsf.between(lo, hi)]   # drop extreme price/sqft outliers
    df = df[df["area_type"].isin(AREA_TYPES)]
    counts = df["locality"].value_counts()
    # localities with too few listings are folded into "Other Bengaluru" for training (they are NOT offered for prediction)
    df.loc[df["locality"].map(counts).fillna(0) < MIN_ROWS_SUPPORTED, "locality"] = OTHER
    log["rows_used"] = int(len(df)); log["ppsf_trim"] = [float(lo), float(hi)]
    print(f"Cleaning: {n0} -> {len(df)} rows. Missing before imputation: {log['missing_before']}")
    return df.reset_index(drop=True), log


def build_pipeline():
    pre = ColumnTransformer([
        ("num", SimpleImputer(strategy="median"), NUMERIC),
        ("bin", "passthrough", BINARY),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
    ])
    return Pipeline([("prep", pre), ("lr", LinearRegression())])


# ------------------------------------------------------------------ formatting helpers (Indian digit grouping)
def inr(v):
    v = int(round(v)); sign = "-" if v < 0 else ""; d = str(abs(v))
    if len(d) > 3:
        head, tail = d[:-3], d[-3:]; parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:]); head = head[:-2]
        if head: parts.insert(0, head)
        d = ",".join(parts) + "," + tail
    return f"{sign}₹{d}"


def short(v):
    return f"₹{v / 1e7:.2f} Cr" if abs(v) >= 1e7 else f"₹{v / 1e5:.1f} L"


def main():
    raw = load_dataset()
    df, log = clean(raw)
    X, y = df[FEATURES], df["price_inr"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=RANDOM_STATE)
    pipe = build_pipeline().fit(X_tr, y_tr)            # fit on TRAIN only
    pred_te, pred_tr = pipe.predict(X_te), pipe.predict(X_tr)
    mse = mean_squared_error(y_te, pred_te)
    metrics = {"r2": r2_score(y_te, pred_te), "mae": mean_absolute_error(y_te, pred_te), "mse": mse, "rmse": float(np.sqrt(mse)),
               "train_r2": r2_score(y_tr, pred_tr), "n_train": int(len(X_tr)), "n_test": int(len(X_te)), "test_size": 0.2, "random_state": RANDOM_STATE}
    resid = y_te.values - pred_te
    metrics["residual_p10"], metrics["residual_p90"] = [float(v) for v in np.percentile(resid, [10, 90])]
    print({k: round(v, 4) if isinstance(v, float) else v for k, v in metrics.items()})

    # ---- coefficients (for explanations and the serverless demo) ----
    lr = pipe.named_steps["lr"]; ohe = pipe.named_steps["prep"].named_transformers_["cat"]
    k = len(NUMERIC) + len(BINARY); coefs = lr.coef_
    num_coefs = dict(zip(NUMERIC + BINARY, map(float, coefs[:k])))
    cat_coefs, cat_mean_effect, off = {}, {}, k
    for col, cats in zip(CATEGORICAL, ohe.categories_):
        cc = {str(c): float(coefs[off + i]) for i, c in enumerate(cats)}; off += len(cats)
        freq = X_tr[col].value_counts(normalize=True)
        cat_coefs[col] = cc; cat_mean_effect[col] = float(sum(cc[str(c)] * f for c, f in freq.items()))
    imputed = X_tr[NUMERIC].fillna(X_tr[NUMERIC].median())          # same imputation the pipeline applies
    num_means = {**{c: float(imputed[c].mean()) for c in NUMERIC}, "ready_to_move": float(X_tr["ready_to_move"].mean())}
    params = {"intercept": float(lr.intercept_), "numeric_features": NUMERIC + BINARY, "numeric_coefs": num_coefs, "numeric_means": num_means,
              "cat_coefs": cat_coefs, "cat_mean_effect": cat_mean_effect, "baseline": float(pred_tr.mean())}

    # ---- reference home: the dataset's own median configuration (used for locality comparisons) ----
    ref = {"total_sqft": float(round(df.total_sqft.median() / 50) * 50), "bhk": float(df.bhk.median()), "bath": float(df.bath.median()),
           "balcony": float(df.balcony.median()), "ready_to_move": 1, "area_type": "Super built-up Area"}

    def predict_df(rows):
        return pipe.predict(pd.DataFrame(rows)[FEATURES])

    # ---- per-locality statistics (real listings) + model estimate for the reference home ----
    df["ppsf"] = df["price_inr"] / df["total_sqft"]
    locs = []
    for name, (zone, lat, lng) in LOCALITIES.items():
        sub = df[df.locality == name]; n_all = int((raw["location"].map(canonical) == name).sum())
        supported = len(sub) >= MIN_ROWS_SUPPORTED
        rec = {"name": name, "zone": zone, "lat": lat, "lng": lng, "n_listings": int(len(sub)), "n_raw": n_all, "supported": bool(supported),
               "data_level": "ok" if len(sub) >= MIN_ROWS_CONFIDENT else "low" if supported else "none"}
        if supported:
            est = float(predict_df([{**ref, "locality": name}])[0])
            rec.update({"avg_price": float(sub.price_inr.mean()), "median_price": float(sub.price_inr.median()), "avg_ppsf": float(sub.ppsf.mean()),
                        "median_ppsf": float(sub.ppsf.median()), "avg_sqft": float(sub.total_sqft.mean()), "est_price": est, "est_ppsf": est / ref["total_sqft"]})
        locs.append(rec)
    sup = [l for l in locs if l["supported"]]
    for rank, l in enumerate(sorted(sup, key=lambda l: -l["est_price"]), 1):
        l["rank_est"] = rank
    zones = []
    for z in ZONES:
        zl = [l for l in sup if l["zone"] == z]; sub = df[df.locality.isin([l["name"] for l in zl])]
        zones.append({"zone": z, "n_localities": len(zl), "n_listings": int(len(sub)), "avg_price": float(sub.price_inr.mean()), "median_price": float(sub.price_inr.median()),
                      "avg_ppsf": float(sub.ppsf.mean()), "est_price": float(np.mean([l["est_price"] for l in zl])), "est_ppsf": float(np.mean([l["est_ppsf"] for l in zl]))})

    # ---- charts data ----
    te = X_te.copy(); te["actual"] = y_te.values; te["predicted"] = pred_te
    samp_all = df.sample(450, random_state=7); samp_te = te.sample(450, random_state=7)
    slope, icpt = np.polyfit(df["total_sqft"], df["price_inr"], 1)
    xs = np.linspace(df["total_sqft"].quantile(.005), df["total_sqft"].quantile(.995), 24)
    by_bhk = df[df.bhk.between(1, 8)].groupby("bhk")["price_inr"].agg(["mean", "count"]).reset_index()
    by_bath = df[df.bath.between(1, 8)].groupby("bath")["price_inr"].agg(["mean", "count"]).reset_index()
    by_type = df.groupby("area_type")["price_inr"].agg(["mean", "count"]).reset_index()
    by_ready = df.groupby("ready_to_move")["price_inr"].agg(["mean", "count"]).reset_index()
    step = 1_000_000; edges = list(range(0, 20_000_001, step))          # ₹10 lakh bands up to ₹2 crore
    counts, _ = np.histogram(df["price_inr"].clip(upper=edges[-1] - 1), bins=edges)
    lab = lambda e: f"₹{e/1e7:g} Cr" if e >= 1e7 else f"₹{e/1e5:g} L"
    hist = [{"bin": lab(edges[i]), "range": lab(edges[i]) + "–" + lab(edges[i + 1]) + ("+" if i == len(counts) - 1 else ""), "count": int(c)} for i, c in enumerate(counts)]
    loc_points = {l["name"]: [{"x": float(r.total_sqft), "y": float(r.price_inr)} for _, r in df[df.locality == l["name"]].head(150).iterrows()] for l in sup}

    nice = {"total_sqft": "Area (sqft)", "bhk": "Bedrooms (BHK)", "bath": "Bathrooms", "balcony": "Balconies", "ready_to_move": "Ready to move"}
    cdf = df[NUMERIC + BINARY + ["price_inr"]].copy(); cdf["bath"] = cdf["bath"].fillna(cdf["bath"].median()); cdf["balcony"] = cdf["balcony"].fillna(cdf["balcony"].median())
    corr = cdf.corr()["price_inr"].drop("price_inr").sort_values(key=abs, ascending=False)
    std_effect = {c: num_coefs[c] * float(X_tr[c].std()) for c in NUMERIC + BINARY}

    # ---- insights from real statistics ----
    hi_l = max(sup, key=lambda l: l["est_price"]); lo_l = min(sup, key=lambda l: l["est_price"])
    hi_p = max(sup, key=lambda l: l["est_ppsf"]); lo_p = min(sup, key=lambda l: l["est_ppsf"])
    q = df["total_sqft"].quantile([.25, .75]); small = df[df.total_sqft <= q[.25]]["price_inr"].mean(); large = df[df.total_sqft >= q[.75]]["price_inr"].mean()
    rdy = df[df.ready_to_move == 1]["price_inr"].mean(); uc = df[df.ready_to_move == 0]["price_inr"].mean()
    zb = sorted(zones, key=lambda z: -z["avg_ppsf"])
    insights = [
        {"title": "Strongest price drivers", "icon": "trend", "stat": f"{nice[corr.index[0]]} r = {corr.iloc[0]:+.2f}",
         "text": "Ranked by correlation with listing price: " + ", ".join(f"{nice[c]} (r = {corr[c]:+.2f})" for c in corr.index[:4]) + ". Locality adds a further, separate effect in the model."},
        {"title": "Size influences price", "icon": "area", "stat": f"{large/small:.1f}× price gap",
         "text": f"Listings in the smallest quartile (≤ {q[.25]:,.0f} sqft) average {inr(small)}; the largest quartile (≥ {q[.75]:,.0f} sqft) averages {inr(large)}. A simple fit gives about {inr(slope)}/sq.ft; the multi-feature model estimates {inr(num_coefs['total_sqft'])}/sq.ft with other features fixed."},
        {"title": "Locality premium", "icon": "pin", "stat": f"{hi_l['name']} highest",
         "text": f"For the dataset's median home ({ref['total_sqft']:.0f} sqft, {ref['bhk']:.0f} BHK), the model's highest estimate is in {hi_l['name']} ({inr(hi_l['est_price'])}) and the lowest in {lo_l['name']} ({inr(lo_l['est_price'])}). Highest estimated ₹/sq.ft: {hi_p['name']} ({inr(hi_p['est_ppsf'])}/sq.ft); lowest: {lo_p['name']} ({inr(lo_p['est_ppsf'])}/sq.ft)."},
        {"title": "Zones compared", "icon": "zone", "stat": f"{zb[0]['zone']} leads on ₹/sq.ft",
         "text": "Average listing price per sq.ft by zone: " + ", ".join(f"{z['zone']} {inr(z['avg_ppsf'])}" for z in zb) + "."},
        {"title": "Ready to move vs under construction", "icon": "age", "stat": f"{rdy/uc:.2f}× ready vs upcoming",
         "text": f"Ready-to-move listings average {inr(rdy)} versus {inr(uc)} for listings with a future possession date (not adjusted for size). The dataset has no property-age column, so age cannot be analysed."},
        {"title": "Bathrooms and bedrooms", "icon": "grade", "stat": f"{'+' if num_coefs['bath'] >= 0 else '−'}{short(abs(num_coefs['bath']))} per bathroom",
         "text": f"Holding area and locality fixed, each extra bathroom is associated with {inr(num_coefs['bath'])} and each extra bedroom with {'+' if num_coefs['bhk'] >= 0 else '−'}{inr(abs(num_coefs['bhk']))}. BHK, bathrooms and area overlap strongly, so a negative BHK term is expected: at a fixed area, more bedrooms means smaller rooms. Read these as model effects, not market rules."},
    ]

    supported_names = [l["name"] for l in sup]
    analytics = {
        "dataset": {
            "name": "Bengaluru House Data (property listings)", "city": "Bengaluru", "state": "Karnataka", "country": "India",
            "source": "Public dataset 'Bengaluru House Price Data' (Kaggle), file Bengaluru_House_Data.csv. Listing (asking) prices, undated historic snapshot; not live market data.",
            "rows_raw": log["rows_raw"], "rows_used": log["rows_used"], "currency": "INR", "price_unit_note": "Dataset price is in lakh rupees; multiplied by 1,00,000 to get INR.",
            "target": "price (listing price in INR)", "features": FEATURES, "n_localities_supported": len(sup), "n_localities_requested": len(LOCALITIES),
            "min_rows_supported": MIN_ROWS_SUPPORTED, "min_rows_confident": MIN_ROWS_CONFIDENT,
            "price_mean": float(df.price_inr.mean()), "price_median": float(df.price_inr.median()), "price_min": float(df.price_inr.min()), "price_max": float(df.price_inr.max()),
            "ppsf_median": float(df.ppsf.median()), "reference_home": ref, "area_types": AREA_TYPES,
        },
        "metrics": metrics,
        "equation": {"intercept": params["intercept"], "numeric_coefs": num_coefs, "std_effect": std_effect,
                     "n_locality_terms": len(cat_coefs["locality"]), "n_area_type_terms": len(cat_coefs["area_type"])},
        "ranges": {c: {"min": float(df[c].min()), "max": float(df[c].max()), "p01": float(df[c].quantile(.01)), "p99": float(df[c].quantile(.99)), "median": float(df[c].median())} for c in NUMERIC},
        "localities": locs, "zones": zones,
        "highlights": {"highest_est": hi_l["name"], "lowest_est": lo_l["name"], "highest_ppsf": hi_p["name"], "lowest_ppsf": lo_p["name"]},
        "locality_points": loc_points,
        "scatter_area_price": [{"x": float(r.total_sqft), "y": float(r.price_inr)} for _, r in samp_all.iterrows() if r.total_sqft <= 6000],
        "actual_vs_predicted": [{"actual": float(r.actual), "predicted": float(r.predicted)} for _, r in samp_te.iterrows()],
        "regression_line": {"slope": float(slope), "intercept": float(icpt), "points": [{"x": float(x), "y": float(slope * x + icpt)} for x in xs]},
        "bhk_avg": [{"bhk": int(r.bhk), "avg": float(r["mean"]), "count": int(r["count"])} for _, r in by_bhk.iterrows()],
        "bath_avg": [{"bath": int(r.bath), "avg": float(r["mean"]), "count": int(r["count"])} for _, r in by_bath.iterrows()],
        "area_type_avg": [{"type": r.area_type, "avg": float(r["mean"]), "count": int(r["count"])} for _, r in by_type.iterrows()],
        "ready_avg": [{"ready": "Ready to move" if r.ready_to_move else "Under construction", "avg": float(r["mean"]), "count": int(r["count"])} for _, r in by_ready.iterrows()],
        "histogram": hist,
        "correlations": [{"feature": c, "label": nice[c], "r": float(corr[c])} for c in corr.index],
        "insights": insights,
    }
    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(pipe, os.path.join(MODEL_DIR, "model.joblib"))
    for name, obj in [("metrics.json", metrics), ("model_params.json", params), ("analytics.json", analytics)]:
        with open(os.path.join(MODEL_DIR, name), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    print("Saved model + metrics + analytics to", MODEL_DIR)
    print("Supported localities:", len(sup), "| unsupported:", [l["name"] for l in locs if not l["supported"]])


if __name__ == "__main__":
    sys.exit(main())
