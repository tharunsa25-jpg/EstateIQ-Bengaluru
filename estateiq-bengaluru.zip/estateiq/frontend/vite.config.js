import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { viteSingleFile } from 'vite-plugin-singlefile'

const demo = process.env.VITE_STATIC === '1'
export default defineConfig({
  plugins: [react(), ...(demo ? [viteSingleFile()] : [])],
  server: { port: 5173, proxy: { '/api': 'http://localhost:5000' } },
})
