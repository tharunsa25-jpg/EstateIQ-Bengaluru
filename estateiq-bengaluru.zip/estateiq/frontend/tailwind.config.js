export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: { 950: '#060b18', 900: '#0a1224', 800: '#0f1a33', 700: '#16233f', 600: '#22335a' },
        cyan2: '#22e4ff', violet2: '#8b5cf6',
        paper: '#f4f6fb', mist: '#e6eaf3',
      },
      fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'], display: ['"Space Grotesk"', 'Inter', 'sans-serif'] },
      keyframes: {
        floaty: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
        fadeUp: { from: { opacity: 0, transform: 'translateY(14px)' }, to: { opacity: 1, transform: 'none' } },
        shimmer: { from: { backgroundPosition: '200% 0' }, to: { backgroundPosition: '-200% 0' } },
        pulseGlow: { '0%,100%': { opacity: .5 }, '50%': { opacity: 1 } },
        scan: { from: { transform: 'translateX(-100%)' }, to: { transform: 'translateX(100%)' } },
      },
      animation: { floaty: 'floaty 6s ease-in-out infinite', fadeUp: 'fadeUp .6s ease both', shimmer: 'shimmer 3s linear infinite', pulseGlow: 'pulseGlow 2.4s ease-in-out infinite', scan: 'scan 1.4s ease-in-out infinite' },
    },
  },
  plugins: [],
}
