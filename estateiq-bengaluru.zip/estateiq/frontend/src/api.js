// API layer. Normal build -> talks to the Flask backend (/api/*).
// Demo build (VITE_STATIC=1) -> same contract, served from the exported trained-model coefficients + SQLite-equivalent localStorage history.
const STATIC = import.meta.env.VITE_STATIC === '1'

async function http(path, opts = {}) {
  let res
  try {
    res = await fetch(`/api${path}`, { headers: { 'Content-Type': 'application/json' }, ...opts })
  } catch {
    throw new Error('Cannot reach the EstateIQ backend. Start it with `python app.py` (port 5000).')
  }
  const data = await res.json().catch(() => ({}))
  if (!res.ok) { const e = new Error(data.error || `Request failed (${res.status})`); e.fields = data.fields; e.details = data; throw e }
  return data
}

let core = null
const getCore = async () => core || (core = await import('./lib/predictCore.js'))
const delay = (ms) => new Promise((r) => setTimeout(r, ms))
const HKEY = 'estateiq_history_blr_v3'
const readH = () => { try { return JSON.parse(localStorage.getItem(HKEY) || '[]') } catch { return [] } }
const writeH = (h) => { try { localStorage.setItem(HKEY, JSON.stringify(h)) } catch { /* storage blocked */ } }
let memH = []
const hist = { get: () => { const h = readH(); return h.length ? h : memH }, set: (h) => { memH = h; writeH(h) } }

function fail(errors) { const e = new Error('Validation failed'); e.fields = errors; return e }

export const api = STATIC ? {
  mode: 'static',
  meta: async () => { const c = await getCore(); const a = c.analytics; return { ranges: a.ranges, limits: c.LIMITS, dataset: a.dataset, localities: a.localities, zones: a.zones.map((z) => z.zone), area_types: a.dataset.area_types, parking: c.PARKING, property_types: c.PROPERTY_TYPES } },
  predict: async (body) => { const c = await getCore(); await delay(700); const { clean, extras, errors } = c.validate(body); if (Object.keys(errors).length) throw fail(errors); return c.runPrediction(clean, extras) },
  compare: async (props) => { const c = await getCore(); await delay(600); const results = props.map((p) => { const { clean, extras, errors } = c.validate(p); if (Object.keys(errors).length) throw fail(errors); return c.runPrediction(clean, extras) }); return { results } },
  curve: async (body) => { const c = await getCore(); const { clean, errors } = c.validate(body); if (Object.keys(errors).length) throw fail(errors); return { points: c.curve(clean) } },
  analytics: async () => { const c = await getCore(); return c.analytics },
  model: async () => { const c = await getCore(); const a = c.analytics; return { dataset: a.dataset, metrics: a.metrics, equation: a.equation, regression_line: a.regression_line, actual_vs_predicted: a.actual_vs_predicted, scatter_area_price: a.scatter_area_price, ranges: a.ranges } },
  insights: async () => { const c = await getCore(); return { insights: c.analytics.insights, correlations: c.analytics.correlations, dataset: c.analytics.dataset } },
  historyList: async () => hist.get(),
  historyAdd: async (inputs) => { const c = await getCore(); const { clean, extras, errors } = c.validate(inputs); if (Object.keys(errors).length) throw fail(errors); const h = hist.get(); const row = { id: Date.now(), created_at: new Date().toISOString(), inputs: { ...clean, ...extras }, result: c.runPrediction(clean, extras) }; hist.set([row, ...h]); return row },
  historyDelete: async (id) => { hist.set(hist.get().filter((r) => r.id !== id)); return { ok: true } },
  historyClear: async () => { hist.set([]); return { ok: true } },
} : {
  mode: 'server',
  meta: () => http('/meta'),
  curve: (body) => http('/curve', { method: 'POST', body: JSON.stringify(body) }),
  predict: (body) => http('/predict', { method: 'POST', body: JSON.stringify(body) }),
  compare: (properties) => http('/compare', { method: 'POST', body: JSON.stringify({ properties }) }),
  analytics: () => http('/analytics'),
  model: () => http('/model'),
  insights: () => http('/insights'),
  historyList: () => http('/history'),
  historyAdd: (inputs) => http('/history', { method: 'POST', body: JSON.stringify({ inputs }) }),
  historyDelete: (id) => http(`/history/${id}`, { method: 'DELETE' }),
  historyClear: () => http('/history', { method: 'DELETE' }),
}
