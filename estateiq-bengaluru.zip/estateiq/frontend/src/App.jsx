import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { ToastProvider } from './components/ui'
import Shell from './components/Shell'
import Landing from './pages/Landing'
import Studio from './pages/Studio'
import Analytics from './pages/Analytics'
import Model from './pages/Model'
import Compare from './pages/Compare'
import History from './pages/History'
import Insights from './pages/Insights'
import About from './pages/About'
import MapPage from './pages/MapPage'

function ScrollTop() { const { pathname } = useLocation(); useEffect(() => { window.scrollTo(0, 0) }, [pathname]); return null }

export default function App() {
  return (
    <ToastProvider>
      <ScrollTop />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route element={<Shell />}>
          <Route path="/studio" element={<Studio />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/map" element={<MapPage />} />
          <Route path="/model" element={<Model />} />
          <Route path="/compare" element={<Compare />} />
          <Route path="/history" element={<History />} />
          <Route path="/insights" element={<Insights />} />
          <Route path="/about" element={<About />} />
        </Route>
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </ToastProvider>
  )
}
