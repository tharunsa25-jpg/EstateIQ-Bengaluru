import { NavLink, Outlet, Link } from 'react-router-dom'
import { useState } from 'react'
import { Sparkles, Map as MapIcon, BarChart3, Brain, GitCompare, History, Lightbulb, Info, Menu, X, Home } from 'lucide-react'
import { Logo } from './ui'
import { api } from '../api'

export const NAV = [
  ['/studio', 'Prediction Studio', Sparkles], ['/analytics', 'Locality Analytics', BarChart3], ['/map', 'Bengaluru Map', MapIcon], ['/model', 'Model Center', Brain],
  ['/compare', 'Comparison Lab', GitCompare], ['/history', 'History', History], ['/insights', 'Insights', Lightbulb], ['/about', 'About', Info],
]

export default function Shell() {
  const [open, setOpen] = useState(false)
  const links = (
    <nav className="flex flex-col gap-1">
      <NavLink to="/" onClick={() => setOpen(false)} className="flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm text-slate-400 hover:bg-white/5 hover:text-white"><Home className="h-4 w-4" />Home</NavLink>
      {NAV.map(([to, label, Icon]) => (
        <NavLink key={to} to={to} onClick={() => setOpen(false)}
          className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm transition ${isActive ? 'bg-gradient-to-r from-cyan2/20 to-violet2/20 font-semibold text-white ring-1 ring-cyan2/30' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
          <Icon className="h-4 w-4" />{label}
        </NavLink>
      ))}
    </nav>
  )
  const foot = (
    <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-xs text-slate-400">
      <p className="mb-1 flex items-center gap-1.5 font-semibold text-slate-200"><span className="h-2 w-2 animate-pulseGlow rounded-full bg-emerald-400" />Linear Regression</p>
      Trained on a public Bengaluru listings dataset. Prices in ₹.{api.mode === 'static' && <span className="mt-1 block text-amber-200/80">Demo mode: runs in your browser using the trained model's coefficients.</span>}
    </div>
  )
  return (
    <div className="min-h-screen lg:flex">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col justify-between border-r border-white/10 bg-ink-900/60 p-5 backdrop-blur-xl lg:flex">
        <div className="space-y-8"><Logo />{links}</div>{foot}
      </aside>
      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-white/10 bg-ink-900/80 px-4 py-3 backdrop-blur-xl lg:hidden">
        <Logo size={30} />
        <button aria-label="Menu" onClick={() => setOpen(!open)} className="rounded-lg p-2 hover:bg-white/10">{open ? <X /> : <Menu />}</button>
      </header>
      {open && <div className="fixed inset-x-0 top-[57px] z-30 animate-fadeUp border-b border-white/10 bg-ink-900/95 p-4 backdrop-blur-xl lg:hidden">{links}</div>}
      <main className="min-w-0 flex-1 px-4 py-8 sm:px-8 lg:px-10"><div className="mx-auto max-w-6xl"><Outlet /></div></main>
    </div>
  )
}
