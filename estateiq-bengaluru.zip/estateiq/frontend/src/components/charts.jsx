import { C, inr, inrShort, num } from '../lib/format'

export const axisProps = { stroke: C.axis, tick: { fill: C.axis, fontSize: 11 }, tickLine: false, axisLine: { stroke: C.grid } }
export const gridProps = { stroke: C.grid, strokeDasharray: '3 3' }

export function Tip({ active, payload, label, rows }) {
  if (!active || !payload?.length) return null
  const p = payload[0].payload
  const items = rows ? rows(p, payload, label) : payload.map((x) => [x.name, x.value])
  return (
    <div className="rounded-xl border border-white/15 bg-ink-900/95 px-3.5 py-2.5 text-xs shadow-xl backdrop-blur">
      {label != null && !rows && <p className="mb-1 font-semibold text-white">{label}</p>}
      {items.map(([k, v], i) => <p key={i} className="flex justify-between gap-5 text-slate-300"><span className="text-slate-400">{k}</span><span className="font-medium text-white">{v}</span></p>)}
    </div>
  )
}
export const fmtMoneyTick = (v) => inrShort(v)
export { inr, inrShort, num }
