import { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { AlertTriangle, CheckCircle2, X } from 'lucide-react'

export function Logo({ size = 36 }) {
  return (
    <Link to="/" className="flex items-center gap-2.5 select-none">
      <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
        <defs><linearGradient id="lg" x1="0" y1="0" x2="40" y2="40"><stop stopColor="#22e4ff" /><stop offset="1" stopColor="#8b5cf6" /></linearGradient></defs>
        <rect width="40" height="40" rx="11" fill="#0f1a33" stroke="url(#lg)" strokeWidth="1.5" />
        <path d="M9 21 20 11l11 10" stroke="url(#lg)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M13 20v10h14V20" stroke="#fff" strokeOpacity=".9" strokeWidth="2.2" strokeLinejoin="round" />
        <path d="M15 27l4-4 3 2 4-5" stroke="url(#lg)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className="font-display text-xl font-bold tracking-tight text-white">Estate<span className="grad-text">IQ</span></span>
    </Link>
  )
}

export function AnimatedNumber({ value, format = (v) => Math.round(v).toLocaleString(), duration = 1100 }) {
  const [v, setV] = useState(0)
  useEffect(() => {
    if (value == null) return
    let raf, t0
    const step = (t) => {
      t0 ??= t
      const p = Math.min((t - t0) / duration, 1)
      setV(value * (1 - Math.pow(1 - p, 4)))
      if (p < 1) raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [value, duration])
  return <>{format(v)}</>
}

export function Spinner({ className = 'h-5 w-5' }) {
  return <span className={`inline-block animate-spin rounded-full border-2 border-white/20 border-t-cyan2 ${className}`} />
}

export function PageLoader({ label = 'Loading data…' }) {
  return (
    <div className="grid min-h-[40vh] place-items-center">
      <div className="flex flex-col items-center gap-4 text-slate-400">
        <div className="relative h-1.5 w-48 overflow-hidden rounded-full bg-white/10"><div className="absolute inset-y-0 w-1/2 animate-scan rounded-full bg-gradient-to-r from-cyan2 to-violet2" /></div>
        <span className="text-sm">{label}</span>
      </div>
    </div>
  )
}

export function ErrorBox({ error, onRetry }) {
  return (
    <div className="glass mx-auto my-10 max-w-lg p-6 text-center">
      <AlertTriangle className="mx-auto mb-3 h-8 w-8 text-amber-300" />
      <p className="mb-1 font-semibold text-white">Something went wrong</p>
      <p className="mb-4 text-sm text-slate-400">{error?.message || String(error)}</p>
      {onRetry && <button className="btn-ghost" onClick={onRetry}>Try again</button>}
    </div>
  )
}

const cache = {}
export function useAsync(key, fn) {
  const [state, setState] = useState({ data: cache[key], error: null, loading: !cache[key] })
  const run = useCallback(() => {
    setState((s) => ({ ...s, loading: !cache[key], error: null }))
    fn().then((data) => { cache[key] = data; setState({ data, error: null, loading: false }) })
      .catch((error) => setState({ data: undefined, error, loading: false }))
  }, [key]) // eslint-disable-line
  useEffect(() => { run() }, [run])
  return { ...state, retry: run }
}
export const invalidate = (k) => delete cache[k]

export function Async({ state, children, label }) {
  if (state.loading && !state.data) return <PageLoader label={label} />
  if (state.error) return <ErrorBox error={state.error} onRetry={state.retry} />
  return children(state.data)
}

const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)
export function ToastProvider({ children }) {
  const [items, setItems] = useState([])
  const push = useCallback((msg, type = 'ok') => {
    const id = Math.random()
    setItems((i) => [...i, { id, msg, type }])
    setTimeout(() => setItems((i) => i.filter((x) => x.id !== id)), 3600)
  }, [])
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2">
        {items.map((t) => (
          <div key={t.id} className="glass animate-fadeUp flex items-center gap-2.5 px-4 py-3 text-sm text-white">
            {t.type === 'ok' ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <AlertTriangle className="h-4 w-4 text-rose-400" />}
            {t.msg}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}

export function Modal({ open, onClose, children, title }) {
  useEffect(() => {
    if (!open) return
    const h = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', h)
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', h); document.body.style.overflow = '' }
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-ink-950/80 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="relative my-6 w-full max-w-5xl rounded-3xl border border-white/10 bg-ink-900 p-5 sm:p-7" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between"><h3 className="font-display text-lg font-semibold text-white">{title}</h3>
          <button aria-label="Close" onClick={onClose} className="rounded-lg p-2 hover:bg-white/10"><X className="h-5 w-5" /></button></div>
        {children}
      </div>
    </div>
  )
}

export function PageHeader({ eyebrow, title, children }) {
  return (
    <div className="mb-8 animate-fadeUp">
      <p className="eyebrow mb-2">{eyebrow}</p>
      <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">{title}</h1>
      {children && <p className="mt-3 max-w-3xl text-slate-400">{children}</p>}
    </div>
  )
}

export function ChartCard({ title, sub, children, className = '', height = 300 }) {
  return (
    <div className={`glass p-5 ${className}`}>
      <h3 className="font-display text-base font-semibold text-white">{title}</h3>
      {sub && <p className="mb-3 mt-1 text-xs text-slate-400">{sub}</p>}
      <div style={{ height }} className="mt-2">{children}</div>
    </div>
  )
}

export function Stat({ label, value, sub, accent = 'text-white' }) {
  return (
    <div className="glass p-5">
      <p className="text-xs uppercase tracking-wider text-slate-400">{label}</p>
      <p className={`mt-2 font-display text-3xl font-bold ${accent}`}>{value}</p>
      {sub && <p className="mt-1 text-xs text-slate-500">{sub}</p>}
    </div>
  )
}

export function Disclaimer({ children }) {
  return <p className="flex gap-2 rounded-xl border border-amber-300/20 bg-amber-300/5 p-3 text-xs leading-relaxed text-amber-100/80"><AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />{children}</p>
}

export function useInView() {
  const ref = useRef(null); const [seen, setSeen] = useState(false)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setSeen(true); io.disconnect() } }, { threshold: .3 })
    io.observe(el); return () => io.disconnect()
  }, [])
  return [ref, seen]
}
