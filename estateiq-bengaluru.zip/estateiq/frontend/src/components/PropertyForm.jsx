import { Info } from 'lucide-react'
import { num } from '../lib/format'

export const defaultsFrom = (meta, locality) => ({
  locality: locality ?? 'Whitefield',
  total_sqft: Math.round(meta.ranges.total_sqft.median / 50) * 50, bhk: 3, bath: 2, balcony: 2, ready_to_move: 1, area_type: meta.area_types[0],
  floors: 4, age: 2, parking: meta.parking[1], property_type: meta.property_types[0],
})

export function clientValidate(v, meta) {
  const e = {}, lim = meta.limits
  const names = { total_sqft: 'Area', bhk: 'Bedrooms', bath: 'Bathrooms', balcony: 'Balconies' }
  for (const f of Object.keys(names)) {
    const n = Number(v[f])
    if (v[f] === '' || Number.isNaN(n)) e[f] = `${names[f]} is required.`
    else if (n < lim[f][0] || n > lim[f][1]) e[f] = `${names[f]} must be between ${lim[f][0]} and ${lim[f][1]}.`
  }
  const L = meta.localities.find((l) => l.name === v.locality)
  if (!L) e.locality = 'Select a locality.'
  else if (!L.supported) e.locality = `${L.name} has too few listings in the dataset (${L.n_raw}) for a reliable estimate.`
  const fl = Number(v.floors), ag = Number(v.age)
  if (!(fl >= 1 && fl <= 60)) e.floors = 'Floors must be 1–60.'
  if (!(ag >= 0 && ag <= 100)) e.age = 'Age must be 0–100 years.'
  return e
}

function Slider({ label, unit, value, min, max, step = 1, onChange, error, hint, id, hardMax }) {
  const n = Number(value)
  const pct = Math.min(100, Math.max(0, ((n - min) / (max - min)) * 100))
  return (
    <div>
      <div className="mb-1.5 flex items-end justify-between">
        <label htmlFor={id} className="label !mb-0">{label}</label>
        <div className="flex items-center gap-1">
          <input aria-label={`${label} value`} type="number" step={step} value={value} max={hardMax} onChange={(e) => onChange(e.target.value === '' ? '' : Number(e.target.value))}
            className="w-20 rounded-lg border border-white/10 bg-ink-900/70 px-2 py-1 text-right text-sm font-semibold text-white outline-none focus:border-cyan2/70" />
          {unit && <span className="text-xs text-slate-500">{unit}</span>}
        </div>
      </div>
      <input id={id} type="range" min={min} max={max} step={step} value={Number.isNaN(n) ? min : Math.min(max, Math.max(min, n))} style={{ '--p': `${pct}%` }} onChange={(e) => onChange(Number(e.target.value))} />
      {hint && !error && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
      {error && <p role="alert" className="mt-1 text-xs text-rose-400">{error}</p>}
    </div>
  )
}

const Fixed = ({ label, value }) => (
  <div><span className="label">{label}</span><div className="field flex items-center justify-between !bg-white/5 text-slate-300" aria-label={`${label}: ${value} (fixed)`}>{value}<span className="text-[10px] uppercase tracking-wider text-slate-500">fixed</span></div></div>
)

export function LocalitySelect({ value, onChange, meta, id = 'loc', error }) {
  return (
    <div>
      <label className="label" htmlFor={id}>Locality</label>
      <select id={id} className="field" value={value} onChange={(e) => onChange(e.target.value)}>
        {meta.zones.map((z) => (
          <optgroup key={z} label={`${z} Bengaluru`}>
            {meta.localities.filter((l) => l.zone === z).map((l) => (
              <option key={l.name} value={l.name} disabled={!l.supported}>{l.name}{!l.supported ? ` — insufficient data (${l.n_raw} listings)` : l.data_level === 'low' ? ' — limited data' : ''}</option>
            ))}
          </optgroup>
        ))}
      </select>
      {error && <p role="alert" className="mt-1 text-xs text-rose-400">{error}</p>}
    </div>
  )
}

export function PropertyForm({ value, onChange, errors = {}, meta, compact = false }) {
  const set = (k) => (v) => onChange({ ...value, [k]: v })
  const r = meta.ranges
  const L = meta.localities.find((l) => l.name === value.locality)
  return (
    <div className="space-y-6">
      <div className={`grid gap-5 ${compact ? '' : 'sm:grid-cols-2'}`}>
        {!compact && <div className="grid gap-5 sm:col-span-2 sm:grid-cols-3"><Fixed label="Country" value="India" /><Fixed label="State" value="Karnataka" /><Fixed label="City" value="Bengaluru" /></div>}
        <div className="sm:col-span-2">
          <LocalitySelect value={value.locality} onChange={set('locality')} meta={meta} id={`loc-${compact ? 'c' : 's'}`} error={errors.locality} />
          {L && <p className="mt-1 text-xs text-slate-500">{L.zone} Bengaluru · {L.supported ? `${L.n_listings} listings in the training data` : 'not enough data'}{L.data_level === 'low' ? ' (limited: estimates for this locality are less reliable)' : ''}</p>}
        </div>
        <Slider id={`area${compact}`} label="Property area" unit="sq.ft" value={value.total_sqft} min={Math.round(r.total_sqft.p01 / 50) * 50} max={Math.round(r.total_sqft.p99 / 50) * 50} step={50} onChange={set('total_sqft')} error={errors.total_sqft} hint={`Typical range ${num(r.total_sqft.p01)}–${num(r.total_sqft.p99)} sq.ft`} />
        <Slider id={`bhk${compact}`} label="Bedrooms (BHK)" value={value.bhk} min={1} max={6} onChange={set('bhk')} error={errors.bhk} />
        <Slider id={`bath${compact}`} label="Bathrooms" value={value.bath} min={1} max={6} onChange={set('bath')} error={errors.bath} />
        <Slider id={`bal${compact}`} label="Balconies" value={value.balcony} min={0} max={3} onChange={set('balcony')} error={errors.balcony} />
        <div>
          <label className="label" htmlFor={`at${compact}`}>Area basis</label>
          <select id={`at${compact}`} className="field" value={value.area_type} onChange={(e) => set('area_type')(e.target.value)}>{meta.area_types.map((a) => <option key={a}>{a}</option>)}</select>
          <p className="mt-1 text-xs text-slate-500">How the listing measured its area (dataset column).</p>
        </div>
        <div>
          <span className="label">Possession</span>
          <button type="button" role="switch" aria-checked={value.ready_to_move === 1} onClick={() => set('ready_to_move')(value.ready_to_move ? 0 : 1)}
            className={`flex w-full items-center justify-between rounded-xl border px-3.5 py-2.5 text-sm transition ${value.ready_to_move ? 'border-cyan2/60 bg-cyan2/10 text-white' : 'border-white/10 bg-ink-900/70 text-slate-300'}`}>
            {value.ready_to_move ? 'Ready to move' : 'Under construction / future date'}
            <span className={`relative h-5 w-9 rounded-full transition ${value.ready_to_move ? 'bg-cyan2' : 'bg-white/20'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${value.ready_to_move ? 'left-[18px]' : 'left-0.5'}`} /></span>
          </button>
        </div>
      </div>

      <fieldset className="rounded-2xl border border-dashed border-white/15 p-4">
        <legend className="flex items-center gap-1.5 px-2 text-xs font-semibold uppercase tracking-wider text-slate-400"><Info className="h-3.5 w-3.5" />Additional details, recorded but not used for pricing</legend>
        <p className="mb-4 text-xs text-slate-500">The Bengaluru dataset has no floors, age, parking or property-type columns, so the model cannot learn their effect. They are saved with the prediction and printed in the report, but they do not change the estimated price.</p>
        <div className={`grid gap-5 ${compact ? '' : 'sm:grid-cols-2 lg:grid-cols-4'}`}>
          <div><label className="label" htmlFor={`fl${compact}`}>Floors in building</label><input id={`fl${compact}`} className="field" type="number" min="1" max="60" value={value.floors} onChange={(e) => set('floors')(e.target.value === '' ? '' : Number(e.target.value))} />{errors.floors && <p role="alert" className="mt-1 text-xs text-rose-400">{errors.floors}</p>}</div>
          <div><label className="label" htmlFor={`ag${compact}`}>Property age (years)</label><input id={`ag${compact}`} className="field" type="number" min="0" max="100" value={value.age} onChange={(e) => set('age')(e.target.value === '' ? '' : Number(e.target.value))} />{errors.age && <p role="alert" className="mt-1 text-xs text-rose-400">{errors.age}</p>}</div>
          <div><label className="label" htmlFor={`pk${compact}`}>Parking</label><select id={`pk${compact}`} className="field" value={value.parking} onChange={(e) => set('parking')(e.target.value)}>{meta.parking.map((p) => <option key={p}>{p}</option>)}</select></div>
          <div><label className="label" htmlFor={`pt${compact}`}>Property type</label><select id={`pt${compact}`} className="field" value={value.property_type} onChange={(e) => set('property_type')(e.target.value)}>{meta.property_types.map((p) => <option key={p}>{p}</option>)}</select></div>
        </div>
      </fieldset>
    </div>
  )
}
