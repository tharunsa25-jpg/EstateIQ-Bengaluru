import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { CartesianGrid, ComposedChart, Line, ResponsiveContainer, Scatter, Tooltip, XAxis, YAxis, ZAxis } from 'recharts'
import { ArrowRight, AlertTriangle } from 'lucide-react'
import { api } from '../api'
import { Tip, axisProps, gridProps } from './charts'
import { C, ZONE_COLOR, inr, inrShort, inrSqft, num } from '../lib/format'

const Row = ({ k, v }) => <div className="flex justify-between gap-4 py-1.5 text-sm"><dt className="text-slate-400">{k}</dt><dd className="text-right font-medium text-white">{v}</dd></div>

// Analytics for one locality: dataset statistics, model estimate for the reference home, and area-vs-predicted-price curve.
export default function LocalityPanel({ loc, data }) {
  const [curve, setCurve] = useState(null)
  const ref = data.dataset.reference_home
  useEffect(() => {
    setCurve(null)
    if (!loc.supported) return
    api.curve({ ...ref, locality: loc.name }).then((r) => setCurve(r.points)).catch(() => setCurve([]))
  }, [loc.name]) // eslint-disable-line
  const sup = data.localities.filter((l) => l.supported)
  return (
    <div className="glass animate-fadeUp space-y-4 p-5">
      <div><span className="rounded-full px-2.5 py-0.5 text-xs font-semibold text-ink-950" style={{ background: ZONE_COLOR[loc.zone] }}>{loc.zone} Bengaluru</span>
        <h3 className="mt-2 font-display text-2xl font-bold text-white">{loc.name}</h3><p className="text-xs text-slate-400">Bengaluru, Karnataka, India</p></div>
      {!loc.supported ? (
        <p className="flex gap-2 rounded-xl border border-amber-300/25 bg-amber-300/5 p-3 text-sm text-amber-100/90"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />The dataset has only {loc.n_raw} listing(s) for {loc.name} (minimum {data.dataset.min_rows_supported}). EstateIQ does not estimate or show prices for it rather than inventing them.</p>
      ) : (<>
        <dl className="divide-y divide-white/10">
          <Row k="Listings in dataset" v={num(loc.n_listings)} />
          <Row k="Average listing price" v={inr(loc.avg_price)} />
          <Row k="Median listing price" v={inr(loc.median_price)} />
          <Row k="Average listing ₹/sq.ft" v={inrSqft(loc.avg_ppsf)} />
          <Row k="Model estimate, median home*" v={inr(loc.est_price)} />
          <Row k="Model est. ₹/sq.ft*" v={inrSqft(loc.est_ppsf)} />
          <Row k="Rank by model estimate" v={`#${loc.rank_est} of ${sup.length}`} />
        </dl>
        {loc.data_level === 'low' && <p className="rounded-lg bg-amber-300/10 p-2 text-xs text-amber-100/90">Limited data ({loc.n_listings} listings): treat the estimate with extra caution.</p>}
        <div>
          <p className="mb-1 text-xs font-semibold text-slate-300">Area vs predicted price ({loc.name})</p>
          <div style={{ height: 200 }}>
            {curve === null ? <div className="grid h-full place-items-center text-xs text-slate-500">Loading model curve…</div> : (
              <ResponsiveContainer><ComposedChart margin={{ right: 8, bottom: 14 }}><CartesianGrid {...gridProps} /><XAxis type="number" dataKey="x" domain={[400, 4000]} {...axisProps} tickFormatter={num} label={{ value: 'Area (sq.ft)', position: 'insideBottom', offset: -8, fill: C.axis, fontSize: 10 }} />
                <YAxis type="number" dataKey="y" {...axisProps} tickFormatter={inrShort} width={58} domain={[0, 'auto']} allowDataOverflow /><ZAxis range={[22, 22]} />
                <Tooltip content={<Tip rows={(p) => [['Area', `${num(p.x)} sq.ft`], ['Price', inr(p.y)]]} />} />
                <Scatter data={(data.locality_points[loc.name] || []).filter((p) => p.x <= 4000)} fill={C.violet} fillOpacity={0.5} />
                <Line data={curve} dataKey="y" stroke={C.cyan} strokeWidth={2.5} dot={false} isAnimationActive={false} /></ComposedChart></ResponsiveContainer>)}
          </div>
          <p className="text-[11px] text-slate-500"><span className="text-cyan-300">Line</span> = model prediction ({ref.bhk} BHK, {ref.bath} bath, {ref.balcony} balconies, ready to move); <span className="text-violet-300">dots</span> = real listings.</p>
        </div>
        <p className="text-[11px] text-slate-500">*Reference home = the dataset's median: {num(ref.total_sqft)} sq.ft, {ref.bhk} BHK, {ref.bath} bath, {ref.balcony} balconies, ready to move, {ref.area_type}. These are model estimates from historic listing data, not live market prices.</p>
        <Link to={`/studio?locality=${encodeURIComponent(loc.name)}`} className="btn-primary w-full">Predict a property in {loc.name} <ArrowRight className="h-4 w-4" /></Link>
      </>)}
    </div>
  )
}
