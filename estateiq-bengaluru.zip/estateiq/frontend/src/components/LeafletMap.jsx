import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { ZONE_COLOR, inr, inrSqft } from '../lib/format'

// Interactive Bengaluru map: one circle marker per requested locality (OpenStreetMap tiles via Leaflet).
// Marker size reflects the model's estimated ₹/sq.ft for the dataset's median home. Grey hollow = not enough data.
export default function LeafletMap({ localities, selected, onSelect, height = 520 }) {
  const el = useRef(null), map = useRef(null), layer = useRef(null), cb = useRef(onSelect)
  cb.current = onSelect

  useEffect(() => {
    map.current = L.map(el.current, { zoomControl: true, scrollWheelZoom: false, attributionControl: true }).setView([12.9716, 77.5946], 11)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' }).addTo(map.current)
    layer.current = L.layerGroup().addTo(map.current)
    return () => { map.current.remove(); map.current = null }
  }, [])

  useEffect(() => {
    if (!map.current) return
    layer.current.clearLayers()
    const vals = localities.filter((l) => l.supported).map((l) => l.est_ppsf), lo = Math.min(...vals), hi = Math.max(...vals)
    localities.forEach((l) => {
      const sel = l.name === selected
      const r = l.supported ? 7 + ((l.est_ppsf - lo) / (hi - lo || 1)) * 11 : 6
      const m = L.circleMarker([l.lat, l.lng], {
        radius: sel ? r + 3 : r, color: sel ? '#ffffff' : l.supported ? '#0a1224' : '#94a3b8', weight: sel ? 3 : 1.5,
        fillColor: l.supported ? ZONE_COLOR[l.zone] : 'transparent', fillOpacity: l.supported ? 0.85 : 0, dashArray: l.supported ? null : '3 3',
      })
      m.bindTooltip(`<b>${l.name}</b> · ${l.zone}<br/>${l.supported ? `${inrSqft(l.est_ppsf)} (model est.)<br/>${inr(l.est_price)} median-home est.` : 'Not enough dataset listings'}`, { direction: 'top' })
      m.on('click', () => cb.current(l.name))
      m.addTo(layer.current)
    })
  }, [localities, selected])

  return (
    <div className="relative overflow-hidden rounded-2xl border border-white/10" style={{ height }}>
      <div ref={el} style={{ height: '100%', width: '100%', background: '#0f1a33' }} role="application" aria-label="Interactive map of Bengaluru localities" />
      <div className="pointer-events-none absolute bottom-3 left-3 z-[500] rounded-xl border border-white/10 bg-ink-900/90 p-2.5 text-[11px] text-slate-300 backdrop-blur">
        {Object.entries(ZONE_COLOR).map(([z, c]) => <span key={z} className="mr-3 inline-flex items-center gap-1"><i className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: c }} />{z}</span>)}
        <span className="inline-flex items-center gap-1"><i className="inline-block h-2.5 w-2.5 rounded-full border border-dashed border-slate-400" />no data</span>
      </div>
    </div>
  )
}
