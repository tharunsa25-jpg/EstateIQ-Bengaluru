import { Bar, BarChart, Cell, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Download, Save, Home, Ruler, BedDouble, Bath, Layers, Clock, MapPin, Waves, Star } from 'lucide-react'
import { AnimatedNumber, Disclaimer, Spinner } from './ui'
import { Tip, axisProps, gridProps } from './charts'
import { C, inr, inrSqft, inrShort, num, signedInr } from '../lib/format'
import { downloadReport } from '../lib/pdf'

export function ResultDashboard({ result, onSave, saving, saved, createdAt }) {
  const x = result.inputs
  const max = Math.max(2.5e6, Math.ceil(Math.max(...result.contributions.map((c) => Math.abs(c.contribution))) * 1.1 / 2.5e6) * 2.5e6)
  const top = result.contributions.slice(0, 3)
  const ex = result.extras || {}
  const items = [[MapPin, 'Locality', `${x.locality} (${result.zone})`], [Ruler, 'Area', `${num(x.total_sqft)} sq.ft`], [BedDouble, 'Bedrooms', `${x.bhk} BHK`], [Bath, 'Bathrooms', x.bath],
    [Layers, 'Balconies', x.balcony], [Clock, 'Possession', x.ready_to_move ? 'Ready to move' : 'Under construction'], [Star, 'Area basis', x.area_type.replace(' Area', '')], [Home, 'City', 'Bengaluru, Karnataka']]
  return (
    <div className="space-y-5 animate-fadeUp">
      <div className="relative overflow-hidden rounded-3xl border border-cyan2/20 bg-gradient-to-br from-ink-800 via-ink-900 to-[#1a1245] p-6 sm:p-8">
        <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-violet2/30 blur-3xl" />
        <p className="eyebrow">Estimated market value</p>
        <p className="mt-2 font-display text-5xl font-bold text-white sm:text-6xl"><span className="grad-text"><AnimatedNumber value={result.price} format={(v) => inr(v)} /></span></p>
        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl bg-white/5 p-3"><p className="text-xs text-slate-400">Price per sq.ft (₹/sq.ft)</p><p className="font-display text-xl font-semibold text-white">{inrSqft(result.price_per_sqft)}</p></div>
          <div className="rounded-xl bg-white/5 p-3 sm:col-span-2"><p className="text-xs text-slate-400">Estimated range (10th–90th percentile of test residuals)</p>
            <p className="font-display text-xl font-semibold text-white">{inr(result.range.low)} <span className="text-slate-500">–</span> {inr(result.range.high)}</p></div>
        </div>
        <p className="mt-3 text-xs text-slate-400">{result.range.note}</p>
        <div className="mt-5 flex flex-wrap gap-3">
          {onSave && <button className="btn-primary" disabled={saving || saved} onClick={onSave}>{saving ? <Spinner /> : <Save className="h-4 w-4" />}{saved ? 'Saved to history' : 'Save to history'}</button>}
          <button className="btn-ghost" onClick={() => downloadReport(result, createdAt)}><Download className="h-4 w-4" />Download PDF report</button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-5">
        <div className="paper p-5 lg:col-span-2">
          <h3 className="mb-3 flex items-center gap-2 font-display font-semibold text-slate-900"><Home className="h-4 w-4 text-violet-600" />Property summary</h3>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
            {items.map(([I, k, v]) => <div key={k}><dt className="flex items-center gap-1.5 text-xs text-slate-500"><I className="h-3 w-3" />{k}</dt><dd className="font-semibold text-slate-900">{v}</dd></div>)}
          </dl>
          <p className="mt-4 rounded-xl bg-white p-3 text-sm text-slate-600">
            Main drivers: {top.map((c, i) => <span key={c.feature}>{i > 0 && ', '}<b className={c.contribution >= 0 ? 'text-emerald-700' : 'text-rose-700'}>{c.label} ({signedInr(c.contribution)})</b></span>)} relative to an average home in the training data ({inr(result.baseline)}).
          </p>
          {(ex.floors != null) && <p className="mt-3 text-xs text-slate-500"><b>Recorded, not used for pricing:</b> {ex.floors} floors · {ex.age} yrs old · {ex.parking} · {ex.property_type}. The dataset has no such columns.</p>}
          {result.locality_data_level === 'low' && <p className="mt-3 rounded-lg bg-amber-100 p-2 text-xs text-amber-900">Limited data: only {result.locality_n} listings for {x.locality} in the training set, so treat this estimate with extra caution.</p>}
        </div>

        <div className="glass p-5 lg:col-span-3">
          <h3 className="font-display font-semibold text-white">Feature contribution</h3>
          <p className="mb-2 mt-1 text-xs text-slate-400">Each bar = coefficient × (your value − training average). Bars sum exactly to the prediction minus the {inr(result.baseline)} baseline. <span className="text-emerald-300">Green</span> raises price, <span className="text-rose-300">red</span> lowers it.</p>
          <div style={{ height: 300 }}>
            <ResponsiveContainer>
              <BarChart data={result.contributions} layout="vertical" margin={{ left: 8, right: 16 }}>
                <CartesianGrid {...gridProps} horizontal={false} />
                <XAxis type="number" {...axisProps} tickFormatter={inrShort} domain={[-max, max]} ticks={[-max, -max / 2, 0, max / 2, max]} />
                <YAxis type="category" dataKey="label" width={92} {...axisProps} />
                <ReferenceLine x={0} stroke="#8fa1c4" />
                <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [['Feature', p.label], ['Your value', typeof p.value === 'number' ? p.value : p.value], ['Effect on price', signedInr(p.contribution)]]} />} />
                <Bar dataKey="contribution" radius={4} barSize={16}>{result.contributions.map((c) => <Cell key={c.feature} fill={c.contribution >= 0 ? C.green : C.rose} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="glass p-5">
        <h3 className="font-display font-semibold text-white">Property comparison</h3>
        <p className="mb-2 mt-1 text-xs text-slate-400">This estimate versus averages from the dataset and the model's zone estimate for a typical home.</p>
        <div style={{ height: 250 }}>
          <ResponsiveContainer>
            <BarChart data={result.comparison.filter((d) => d.value != null)} margin={{ left: 0, right: 10 }}>
              <CartesianGrid {...gridProps} vertical={false} />
              <XAxis dataKey="name" {...axisProps} interval={0} />
              <YAxis {...axisProps} tickFormatter={inrShort} width={56} />
              <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [[p.name, inr(p.value)]]} />} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={64}>{result.comparison.map((d, i) => <Cell key={i} fill={i === 0 ? C.cyan : C.violet} />)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <Disclaimer>{result.disclaimer}</Disclaimer>
    </div>
  )
}
