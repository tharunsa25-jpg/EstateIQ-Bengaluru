import { useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Wand2, RotateCcw } from 'lucide-react'
import { api } from '../api'
import { Async, PageHeader, Spinner, useAsync, useToast, Disclaimer, invalidate } from '../components/ui'
import { PropertyForm, clientValidate, defaultsFrom } from '../components/PropertyForm'
import { ResultDashboard } from '../components/ResultDashboard'

export default function Studio() {
  const st = useAsync('meta', api.meta)
  return (
    <>
      <PageHeader eyebrow="Smart Price Prediction Studio" title="Describe a Bengaluru property. Get a model-driven estimate.">
        Your inputs are sent to the trained Linear Regression model, never to a lookup table or random generator.
      </PageHeader>
      <Async state={st}>{(meta) => <Workspace meta={meta} />}</Async>
    </>
  )
}

function Workspace({ meta }) {
  const toast = useToast()
  const [params] = useSearchParams()
  const [form, setForm] = useState(() => { const q = params.get('locality'); const L = meta.localities.find((l) => l.name === q && l.supported); return defaultsFrom(meta, L?.name) })
  const [errors, setErrors] = useState({})
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState(null)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const out = useRef(null)

  useEffect(() => { if (result) out.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }) }, [result])

  const submit = async (e) => {
    e.preventDefault()
    const errs = clientValidate(form, meta)
    setErrors(errs)
    if (Object.keys(errs).length) return toast('Please fix the highlighted fields', 'err')
    setBusy(true); setSaved(false)
    try { setResult(await api.predict(form)) }
    catch (err) { if (err.fields) setErrors(err.fields); toast(err.message, 'err') }
    finally { setBusy(false) }
  }
  const save = async () => {
    setSaving(true)
    try { await api.historyAdd(result.inputs); invalidate('history'); setSaved(true); toast('Prediction saved to history') }
    catch (err) { toast(err.message, 'err') } finally { setSaving(false) }
  }

  return (
    <div className="space-y-8">
      <form onSubmit={submit} noValidate className="glass relative p-5 sm:p-7">
        <PropertyForm value={form} onChange={setForm} errors={errors} meta={meta} />
        <div className="mt-7 flex flex-wrap items-center gap-3">
          <button className="btn-primary min-w-44" disabled={busy}>{busy ? <><Spinner /> Predicting…</> : <><Wand2 className="h-4 w-4" />Predict Price</>}</button>
          <button type="button" className="btn-ghost" onClick={() => { setForm(defaultsFrom(meta)); setErrors({}); setResult(null) }}><RotateCcw className="h-4 w-4" />Reset</button>
        </div>
        {busy && <div className="absolute inset-x-0 bottom-0 h-1 overflow-hidden rounded-b-2xl"><div className="h-full w-1/2 animate-scan bg-gradient-to-r from-cyan2 to-violet2" /></div>}
      </form>
      <div ref={out} className="scroll-mt-20">
        {busy && !result && <div className="glass grid h-48 place-items-center text-slate-400"><div className="flex items-center gap-3"><Spinner className="h-6 w-6" />Running the regression model…</div></div>}
        {result && <div className={busy ? 'opacity-50 transition' : 'transition'}><ResultDashboard result={result} onSave={save} saving={saving} saved={saved} /></div>}
        {!result && !busy && <Disclaimer>Estimates only, in Indian Rupees (₹). The model is a Linear Regression trained on a historic snapshot of Bengaluru property listing prices (not transactions, not live market data), so results depend on that dataset's quality and age. Not a valuation.</Disclaimer>}
      </div>
    </div>
  )
}
