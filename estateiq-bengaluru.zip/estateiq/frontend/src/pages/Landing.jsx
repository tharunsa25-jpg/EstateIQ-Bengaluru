import { Link } from 'react-router-dom'
import { useState } from 'react'
import { ArrowRight, BarChart3, Database, Scissors, Cpu, Gauge, Rocket, Menu, X, Github, ShieldCheck } from 'lucide-react'
import { Logo, AnimatedNumber, useAsync, useInView } from '../components/ui'
import { api } from '../api'
import { num, inr } from '../lib/format'

function Skyline() {
  const b = [[20, 150, 54, '#16233f'], [80, 100, 46, '#1c2c52'], [132, 170, 60, '#22335a'], [198, 70, 52, '#1c2c52'], [256, 130, 44, '#16233f'], [306, 90, 58, '#22335a']]
  return (
    <svg viewBox="0 0 380 280" className="w-full max-w-lg drop-shadow-[0_20px_60px_rgba(139,92,246,.35)]" role="img" aria-label="Illustration of city buildings with a rising price trend line">
      <defs>
        <linearGradient id="gl" x1="0" x2="1"><stop stopColor="#22e4ff" /><stop offset="1" stopColor="#8b5cf6" /></linearGradient>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#8b5cf6" stopOpacity=".25" /><stop offset="1" stopColor="#22e4ff" stopOpacity="0" /></linearGradient>
      </defs>
      <circle cx="300" cy="60" r="44" fill="url(#sky)" />
      {b.map(([x, h, w, c], i) => (
        <g key={i}>
          <rect x={x} y={250 - h} width={w} height={h} rx="5" fill={c} stroke="rgba(255,255,255,.12)" />
          {Array.from({ length: Math.floor(h / 22) }).map((_, r) => [0, 1].map((k) => (
            <rect key={r + '-' + k} x={x + 9 + k * (w / 2 - 4)} y={250 - h + 10 + r * 20} width={w / 2 - 14} height="9" rx="2" fill={(r + k + i) % 3 === 0 ? '#22e4ff' : '#fff'} opacity={(r + k + i) % 3 === 0 ? .85 : .12} className={(r + k + i) % 3 === 0 ? 'animate-pulseGlow' : ''} />
          )))}
        </g>
      ))}
      <rect x="0" y="250" width="380" height="3" fill="url(#gl)" />
      <path d="M10 215 C70 205 90 160 140 150 S220 90 260 70 S330 30 370 18" fill="none" stroke="url(#gl)" strokeWidth="3.5" strokeLinecap="round" strokeDasharray="6 6" className="animate-shimmer" />
      {[[140, 150], [260, 70], [370, 18]].map(([x, y]) => <circle key={x} cx={x} cy={y} r="6" fill="#fff" stroke="#8b5cf6" strokeWidth="3" />)}
    </svg>
  )
}

const steps = [
  [Database, 'Real data', 'Over 12,000 real Bengaluru property listings, each with locality, area, BHK and bathrooms, supply the training signal.'],
  [Scissors, 'Split & clean', 'Missing values imputed, localities one-hot encoded, 80/20 train/test split with no leakage.'],
  [Cpu, 'Fit the line', 'Ordinary least squares finds the coefficients that minimise squared error.'],
  [Gauge, 'Evaluate', 'R², MAE, MSE and RMSE are measured on homes the model never saw.'],
  [Rocket, 'Predict', 'Your inputs go through ŷ = b₀ + b₁x₁ + … + bₙxₙ for an instant estimate.'],
]

export default function Landing() {
  const [menu, setMenu] = useState(false)
  const st = useAsync('landing', async () => ({ model: await api.model() }))
  const [ref, seen] = useInView()
  const m = st.data?.model
  const links = [['#how', 'How it works'], ['#/studio', 'Prediction Studio'], ['#/analytics', 'Analytics'], ['#/map', 'Map'], ['#/model', 'Model'], ['#/about', 'About']]
  return (
    <div className="min-h-screen overflow-x-hidden">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-ink-950/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-8">
          <Logo />
          <nav className="hidden items-center gap-7 text-sm text-slate-300 md:flex">{links.map(([h, l]) => <a key={l} href={h} className="transition hover:text-cyan2">{l}</a>)}</nav>
          <Link to="/studio" className="btn-primary hidden !py-2 md:inline-flex">Start Prediction</Link>
          <button aria-label="Menu" className="rounded-lg p-2 md:hidden" onClick={() => setMenu(!menu)}>{menu ? <X /> : <Menu />}</button>
        </div>
        {menu && <div className="animate-fadeUp space-y-1 border-t border-white/10 px-4 py-3 md:hidden">{links.map(([h, l]) => <a key={l} href={h} onClick={() => setMenu(false)} className="block rounded-lg px-3 py-2.5 hover:bg-white/5">{l}</a>)}</div>}
      </header>

      <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-14 sm:px-8 lg:grid-cols-2 lg:pt-24">
        <div className="animate-fadeUp">
          <span className="inline-flex items-center gap-2 rounded-full border border-cyan2/30 bg-cyan2/10 px-3.5 py-1.5 text-xs font-medium text-cyan2"><span className="h-1.5 w-1.5 animate-pulseGlow rounded-full bg-cyan2" />Bengaluru · Multiple Linear Regression</span>
          <h1 className="mt-5 font-display text-4xl font-bold leading-[1.08] text-white sm:text-5xl lg:text-6xl">Discover the True Value of <span className="grad-text">Your Property</span></h1>
          <p className="mt-5 max-w-xl text-lg text-slate-400">EstateIQ fits a multiple linear regression model on real Bengaluru property listings. It learns how area, bedrooms, bathrooms and locality each add to or subtract from price in ₹, then applies those learned coefficients to your home, with a transparent breakdown of every rupee.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/studio" className="btn-primary">Start Prediction <ArrowRight className="h-4 w-4" /></Link>
            <Link to="/analytics" className="btn-ghost"><BarChart3 className="h-4 w-4" />Explore Analytics</Link>
          </div>
          <p className="mt-5 flex items-center gap-2 text-xs text-slate-500"><ShieldCheck className="h-4 w-4" />Estimates only, in ₹. Based on a historic snapshot of Bengaluru listing prices (not live market data). Not a valuation.</p>
        </div>
        <div className="relative flex justify-center animate-floaty"><Skyline /></div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-8">
        <div ref={ref} className="glass grid grid-cols-2 gap-6 p-6 sm:p-8 lg:grid-cols-4">
          {[[m?.dataset.rows_used, (v) => num(v), 'Real Bengaluru listings used'], [m?.metrics.r2, (v) => v.toFixed(3), 'R² on unseen test data'], [m?.dataset.n_localities_supported, (v) => Math.round(v), 'Bengaluru localities supported'], [m?.dataset.price_median, (v) => inr(v), 'Median listing price in data']].map(([v, f, l]) => (
            <div key={l} className="text-center"><p className="font-display text-3xl font-bold text-white sm:text-4xl"><span className="grad-text">{seen && v != null ? <AnimatedNumber value={v} format={f} /> : '—'}</span></p><p className="mt-1 text-xs uppercase tracking-wider text-slate-400">{l}</p></div>
          ))}
        </div>
      </section>

      <section id="how" className="mx-auto max-w-7xl px-4 py-20 sm:px-8">
        <p className="eyebrow">How it works</p>
        <h2 className="mt-2 font-display text-3xl font-bold text-white sm:text-4xl">The machine-learning workflow</h2>
        <p className="mt-3 max-w-2xl text-slate-400">The same five steps run in <code className="text-cyan2">backend/train_model.py</code>; nothing on this site is hard-coded or random.</p>
        <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          {steps.map(([I, t, d], i) => (
            <div key={t} className="glass group relative p-5 transition hover:-translate-y-1 hover:border-cyan2/40">
              <span className="absolute right-4 top-3 font-display text-4xl font-bold text-white/5">0{i + 1}</span>
              <div className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-cyan2/25 to-violet2/25 text-cyan2"><I className="h-5 w-5" /></div>
              <h3 className="font-display font-semibold text-white">{t}</h3><p className="mt-2 text-sm text-slate-400">{d}</p>
              {i < steps.length - 1 && <ArrowRight className="absolute -right-3.5 top-1/2 z-10 hidden h-5 w-5 -translate-y-1/2 text-cyan2/60 lg:block" />}
            </div>
          ))}
        </div>
        <div className="paper mt-12 grid items-center gap-6 p-6 sm:p-8 md:grid-cols-2">
          <div><h3 className="font-display text-2xl font-bold text-slate-900">One equation, fully explainable</h3><p className="mt-2 text-slate-600">Unlike black-box models, every coefficient can be read directly, so you can see exactly why EstateIQ values a home the way it does.</p>
            <Link to="/model" className="mt-4 inline-flex items-center gap-1.5 font-semibold text-violet-700 hover:underline">Open Model Intelligence Center <ArrowRight className="h-4 w-4" /></Link></div>
          <div className="rounded-2xl bg-ink-900 p-5 text-center font-mono text-sm text-cyan2 sm:text-base">Price = b<sub>0</sub> + b<sub>1</sub>·Area + b<sub>2</sub>·Bedrooms + … + b<sub>n</sub>·X<sub>n</sub></div>
        </div>
      </section>

      <footer className="border-t border-white/10 bg-ink-900/60">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-8 text-sm text-slate-500 sm:flex-row sm:px-8">
          <Logo size={28} />
          <p>EstateIQ – Bengaluru Smart Property Price Prediction System · ML Academic Mini Project</p>
          <p>Prices in INR (₹). Data: public Bengaluru listings dataset (historic snapshot).</p>
        </div>
      </footer>
    </div>
  )
}
