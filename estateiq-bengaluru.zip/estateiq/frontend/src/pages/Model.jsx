import { Bar, BarChart, CartesianGrid, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis, Cell } from 'recharts'
import { api } from '../api'
import { Async, ChartCard, Disclaimer, PageHeader, Stat, useAsync } from '../components/ui'
import { Tip, axisProps, gridProps } from '../components/charts'
import { C, inr, inrSqft, inrShort, num, signedInr } from '../lib/format'

const LABEL = { total_sqft: 'Area', bhk: 'Bedrooms (BHK)', bath: 'Bathrooms', balcony: 'Balconies', ready_to_move: 'Ready to move' }

export default function Model() {
  const st = useAsync('model', api.model)
  return (
    <>
      <PageHeader eyebrow="Model Intelligence Center" title="Inside the Linear Regression model">Everything on this page is read from the trained model and its evaluation on held-out data.</PageHeader>
      <Async state={st}>{(d) => <Body d={d} />}</Async>
    </>
  )
}

function Body({ d }) {
  const m = d.metrics, ds = d.dataset, eq = d.equation
  const stdData = Object.entries(eq.std_effect).map(([k, v]) => ({ name: LABEL[k], v })).sort((a, b) => Math.abs(b.v) - Math.abs(a.v))
  const info = [['Dataset', ds.name], ['City', 'Bengaluru, Karnataka, India'], ['Source', ds.source], ['Rows used', `${num(ds.rows_used)} (of ${num(ds.rows_raw)})`], ['Target variable', ds.target], ['Currency', ds.currency + ' (' + ds.price_unit_note + ')']]
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="R² score" value={m.r2.toFixed(4)} sub={`${(m.r2 * 100).toFixed(1)}% of price variance explained (test set)`} accent="grad-text" />
        <Stat label="MAE" value={inr(m.mae)} sub="Mean absolute error" />
        <Stat label="MSE" value={m.mse.toExponential(3).replace('e+', ' × 10^')} sub="Mean squared error (INR²)" />
        <Stat label="RMSE" value={inr(m.rmse)} sub="Root mean squared error" />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="paper p-6"><h3 className="font-display text-xl font-bold text-slate-900">What is Linear Regression?</h3>
          <p className="mt-2 text-slate-600">A supervised learning algorithm that models a target as a weighted sum of input features. Training chooses the weights (coefficients) that minimise the sum of squared differences between predicted and actual prices (ordinary least squares).</p>
          <h3 className="mt-5 font-display text-xl font-bold text-slate-900">Why use it here?</h3>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-slate-600"><li>Fully interpretable: every coefficient is a ₹-per-unit effect.</li><li>Fast to train, with no tuning needed.</li><li>A strong, honest baseline for tabular price data.</li><li>Its limit: it cannot capture curves or interactions on its own.</li></ul></div>
        <div className="glass p-6"><h3 className="font-display text-lg font-semibold text-white">Dataset information</h3>
          <dl className="mt-3 divide-y divide-white/10 text-sm">{info.map(([k, v]) => <div key={k} className="flex justify-between gap-6 py-2"><dt className="text-slate-400">{k}</dt><dd className="text-right text-white">{v}</dd></div>)}</dl>
          <p className="mt-3 text-xs text-slate-400">Localities with fewer than {ds.min_rows_supported} listings are not offered for prediction ({ds.n_localities_supported} of {ds.n_localities_requested} requested localities are supported). Prices are listing prices from a historic snapshot, not live market data.</p></div>
      </div>

      <div className="glass p-6"><h3 className="font-display text-lg font-semibold text-white">Input features</h3>
        <div className="mt-3 flex flex-wrap gap-2">{[...ds.features].map((f) => <span key={f} className="rounded-lg border border-cyan2/30 bg-cyan2/10 px-3 py-1 font-mono text-xs text-cyan2">{f}{f === 'locality' ? ' (one-hot, ' + eq.n_locality_terms + ' columns)' : f === 'area_type' ? ' (one-hot, ' + eq.n_area_type_terms + ' columns)' : ''}</span>)}</div>
        <p className="mt-3 text-sm text-slate-400"><b className="text-white">total_sqft</b> ranges like "2100 - 2850" are averaged; other units are converted to sq.ft. <b className="text-white">locality</b> is categorical, so it is one-hot encoded (never a number); small localities are grouped as "Other Bengaluru" for training. <b className="text-white">Target:</b> <span className="font-mono text-violet-300">price</span> in ₹.</p></div>

      <div className="glass p-6"><h3 className="font-display text-lg font-semibold text-white">Regression equation</h3>
        <p className="mt-2 rounded-xl bg-ink-900 p-4 text-center font-mono text-sm text-cyan2 sm:text-base">Price = b<sub>0</sub> + b<sub>1</sub>X<sub>1</sub> + b<sub>2</sub>X<sub>2</sub> + … + b<sub>n</sub>X<sub>n</sub></p>
        <p className="mt-4 text-xs uppercase tracking-wider text-slate-400">Learned coefficients (₹ per unit)</p>
        <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          <div className="rounded-xl bg-white/5 p-3 text-sm"><span className="font-mono text-slate-400">b₀ (intercept)</span><br /><b className="text-white">{inr(eq.intercept)}</b></div>
          {Object.entries(eq.numeric_coefs).map(([k, v], i) => <div key={k} className="rounded-xl bg-white/5 p-3 text-sm"><span className="font-mono text-slate-400">b{i + 1} · {LABEL[k]}</span><br /><b className={v >= 0 ? 'text-emerald-300' : 'text-rose-300'}>{signedInr(v)}</b></div>)}
          <div className="rounded-xl bg-white/5 p-3 text-sm"><span className="font-mono text-slate-400">+ {eq.n_locality_terms} locality terms + {eq.n_area_type_terms} area-basis terms</span><br /><b className="text-white">one of each is added per property</b></div>
        </div></div>

      <div className="grid gap-5 lg:grid-cols-2">
        <ChartCard title="Regression line & actual data points" sub={`Simple fit of price on area alone: ≈ ${inrSqft(d.regression_line.slope)}. (The full model uses all features; this view shows the idea.)`} height={310}>
          <ResponsiveContainer><ComposedChart margin={{ left: 0, right: 12, bottom: 16 }}>
            <CartesianGrid {...gridProps} /><XAxis type="number" dataKey="x" {...axisProps} tickFormatter={num} domain={[0, 6000]} allowDataOverflow label={{ value: 'Area (sq.ft)', position: 'insideBottom', offset: -10, fill: C.axis, fontSize: 11 }} />
            <YAxis type="number" dataKey="y" {...axisProps} tickFormatter={inrShort} width={56} domain={[0, 4e7]} ticks={[0, 1e7, 2e7, 3e7, 4e7]} allowDataOverflow /><ZAxis range={[24, 24]} />
            <Tooltip content={<Tip rows={(p) => [['Area', `${num(p.x)} sq.ft`], ['Price', inr(p.y)]]} />} />
            <Scatter name="Homes" data={d.scatter_area_price} fill={C.cyan} fillOpacity={0.45} />
            <Line name="Fit" data={d.regression_line.points} dataKey="y" type="linear" stroke={C.amber} strokeWidth={3} dot={false} isAnimationActive={false} />
          </ComposedChart></ResponsiveContainer></ChartCard>
        <ChartCard title="Feature effect per +1 standard deviation" sub="Coefficient × feature std. dev. makes features comparable (locality effects not shown)." height={310}>
          <ResponsiveContainer><BarChart data={stdData} layout="vertical" margin={{ left: 8, right: 16 }}><CartesianGrid {...gridProps} horizontal={false} /><XAxis type="number" {...axisProps} tickFormatter={inrShort} /><YAxis type="category" dataKey="name" {...axisProps} width={76} /><ReferenceLine x={0} stroke="#8fa1c4" />
            <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [[p.name, signedInr(p.v)]]} />} />
            <Bar dataKey="v" radius={4} barSize={16}>{stdData.map((s) => <Cell key={s.name} fill={s.v >= 0 ? C.green : C.rose} />)}</Bar></BarChart></ResponsiveContainer></ChartCard>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="glass p-6"><h3 className="font-display text-lg font-semibold text-white">Training & testing process</h3>
          <ol className="mt-3 space-y-3 text-sm text-slate-300">
            {[['Clean', 'Parse area text to numbers, drop listings with no area/price, impossible rows (under 300 sq.ft per bedroom) and extreme ₹/sq.ft outliers; map free-text locations to localities.'], ['Split', `${num(m.n_train)} training rows / ${num(m.n_test)} test rows (80/20, random_state=${m.random_state}).`], ['Preprocess (fit on train only)', 'Median-impute missing bathrooms/balconies/BHK, one-hot encode locality and area basis. Test rows are only transformed, never fitted on, so there is no data leakage.'], ['Train', 'scikit-learn LinearRegression (OLS).'], ['Evaluate', `Metrics computed on the unseen test set. Train R² = ${m.train_r2.toFixed(3)} vs test R² = ${m.r2.toFixed(3)}, so there is no sign of overfitting.`], ['Persist', 'Whole pipeline saved with Joblib and loaded by Flask for every prediction.']].map(([t, x], i) => <li key={t} className="flex gap-3"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-gradient-to-br from-cyan2 to-violet2 text-xs font-bold text-ink-950">{i + 1}</span><span><b className="text-white">{t}.</b> {x}</span></li>)}
          </ol></div>
        <ChartCard title="Actual vs predicted (test set)" sub="Closer to the dashed line = better. Wider scatter at high prices shows where a linear model struggles." height={330}>
          <ResponsiveContainer><ScatterChart margin={{ left: 0, right: 12, bottom: 16 }}><CartesianGrid {...gridProps} /><XAxis type="number" dataKey="actual" {...axisProps} tickFormatter={inrShort} domain={[0, 4e7]} ticks={[0, 1e7, 2e7, 3e7, 4e7]} allowDataOverflow label={{ value: 'Actual', position: 'insideBottom', offset: -10, fill: C.axis, fontSize: 11 }} /><YAxis type="number" dataKey="predicted" {...axisProps} tickFormatter={inrShort} width={56} domain={[0, 4e7]} ticks={[0, 1e7, 2e7, 3e7, 4e7]} allowDataOverflow /><ZAxis range={[24, 24]} />
            <ReferenceLine segment={[{ x: 0, y: 0 }, { x: 2.5e6, y: 2.5e6 }]} stroke={C.amber} strokeDasharray="6 4" />
            <Tooltip content={<Tip rows={(p) => [['Actual', inr(p.actual)], ['Predicted', inr(p.predicted)]]} />} /><Scatter data={d.actual_vs_predicted} fill={C.violet} fillOpacity={0.55} /></ScatterChart></ResponsiveContainer></ChartCard>
      </div>
      <Disclaimer>Prediction ranges use the 10th–90th percentile of test residuals ({inr(m.residual_p10)} to {signedInr(m.residual_p90)}). They describe typical past errors and are not a guaranteed confidence interval. Errors are larger for expensive homes. Predictions depend on dataset quality and age; this is a historic listing snapshot, not live data.</Disclaimer>
    </div>
  )
}
