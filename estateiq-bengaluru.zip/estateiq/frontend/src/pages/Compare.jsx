import { useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Plus, X, GitCompare } from 'lucide-react'
import { api } from '../api'
import { Async, ChartCard, PageHeader, Spinner, useAsync, useToast } from '../components/ui'
import { PropertyForm, clientValidate, defaultsFrom } from '../components/PropertyForm'
import { Tip, axisProps, gridProps } from '../components/charts'
import { C, inr, inrSqft, inrShort, num } from '../lib/format'

const COLORS = [C.cyan, C.violet, C.amber]
const NAMES = ['Property A', 'Property B', 'Property C']

export default function Compare() {
  const st = useAsync('meta', api.meta)
  return (<><PageHeader eyebrow="Property comparison lab" title="Put two or three properties head to head">Each property is run through the same trained model, so differences come only from the features you change.</PageHeader><Async state={st}>{(m) => <Lab meta={m} />}</Async></>)
}

function Lab({ meta }) {
  const toast = useToast()
  const [props, setProps] = useState(() => [defaultsFrom(meta), { ...defaultsFrom(meta), locality: 'Koramangala', total_sqft: 1800, bhk: 3, bath: 3 }])
  const [errs, setErrs] = useState([{}, {}, {}])
  const [res, setRes] = useState(null)
  const [busy, setBusy] = useState(false)

  const run = async () => {
    const e = props.map((p) => clientValidate(p, meta)); setErrs(e)
    if (e.some((x) => Object.keys(x).length)) return toast('Fix the highlighted fields', 'err')
    setBusy(true)
    try { setRes((await api.compare(props)).results) } catch (err) { toast(err.message, 'err') } finally { setBusy(false) }
  }
  const data = (res || []).map((r, i) => ({ name: NAMES[i], price: r.price, ppsf: r.price_per_sqft, area: r.inputs.total_sqft, beds: r.inputs.bhk, baths: r.inputs.bath, loc: r.inputs.locality }))
  const chart = (title, key, fmt, tick) => (
    <ChartCard title={title} height={220}>
      <ResponsiveContainer><BarChart data={data} margin={{ right: 8 }}><CartesianGrid {...gridProps} vertical={false} /><XAxis dataKey="name" {...axisProps} /><YAxis {...axisProps} tickFormatter={tick} width={52} />
        <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [[p.name, fmt(p[key])], ['Location', p.loc]]} />} />
        <Bar dataKey={key} radius={[6, 6, 0, 0]} maxBarSize={56}>{data.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}</Bar></BarChart></ResponsiveContainer>
    </ChartCard>)

  return (
    <div className="space-y-6">
      <div className={`grid gap-5 ${props.length === 3 ? 'xl:grid-cols-3' : 'xl:grid-cols-2'}`}>
        {props.map((p, i) => (
          <div key={i} className="glass p-5" style={{ borderTop: `3px solid ${COLORS[i]}` }}>
            <div className="mb-4 flex items-center justify-between"><h3 className="font-display font-semibold text-white">{NAMES[i]}</h3>
              {i === 2 && <button aria-label="Remove property C" className="rounded-lg p-1.5 hover:bg-white/10" onClick={() => { setProps(props.slice(0, 2)); setRes(null) }}><X className="h-4 w-4" /></button>}</div>
            <PropertyForm compact value={p} errors={errs[i]} meta={meta} onChange={(v) => setProps(props.map((x, j) => (j === i ? v : x)))} />
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-3">
        <button className="btn-primary" onClick={run} disabled={busy}>{busy ? <><Spinner />Comparing…</> : <><GitCompare className="h-4 w-4" />Compare properties</>}</button>
        {props.length < 3 && <button className="btn-ghost" onClick={() => setProps([...props, { ...defaultsFrom(meta), locality: 'Electronic City', total_sqft: 1000, bhk: 2, bath: 2 }])}><Plus className="h-4 w-4" />Add third property</button>}
      </div>
      {res && (
        <div className="space-y-5 animate-fadeUp">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{data.map((d, i) => <div key={i} className="glass p-4" style={{ borderLeft: `4px solid ${COLORS[i]}` }}><p className="text-xs text-slate-400">{d.name} · {d.loc}</p><p className="font-display text-2xl font-bold text-white">{inr(d.price)}</p><p className="text-sm text-slate-400">{inrSqft(d.ppsf)} · {num(d.area)} sq.ft · {d.beds} BHK · {d.baths} bath</p></div>)}</div>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {chart('Predicted price', 'price', inr, inrShort)}{chart('Price per sq.ft (₹/sq.ft)', 'ppsf', inrSqft, inrShort)}{chart('Area (sq.ft)', 'area', (v) => `${num(v)} sq.ft`, num)}
            {chart('Bedrooms (BHK)', 'beds', (v) => `${v} BHK`, (v) => v)}{chart('Bathrooms', 'baths', (v) => v, (v) => v)}
          </div>
        </div>
      )}
    </div>
  )
}
