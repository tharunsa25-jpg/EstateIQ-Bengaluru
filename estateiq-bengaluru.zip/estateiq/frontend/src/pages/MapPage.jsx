import { useState } from 'react'
import { api } from '../api'
import { Async, PageHeader, useAsync, Disclaimer } from '../components/ui'
import LeafletMap from '../components/LeafletMap'
import LocalityPanel from '../components/LocalityPanel'
import { LocalitySelect } from '../components/PropertyForm'

export default function MapPage() {
  const st = useAsync('analytics', api.analytics)
  const meta = useAsync('meta', api.meta)
  return (
    <>
      <PageHeader eyebrow="Bengaluru map" title="Explore localities on the map">Click a marker to open that locality's analytics. Marker size shows the model's estimated ₹/sq.ft for the dataset's median home; colour shows the zone.</PageHeader>
      <Async state={st}>{(data) => <Body data={data} meta={meta.data} />}</Async>
    </>
  )
}

function Body({ data, meta }) {
  const [sel, setSel] = useState('Whitefield')
  const loc = data.localities.find((l) => l.name === sel)
  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-5">
        <div className="space-y-3 lg:col-span-3">
          {meta && <LocalitySelect id="map-loc" value={sel} onChange={setSel} meta={meta} />}
          <LeafletMap localities={data.localities} selected={sel} onSelect={setSel} />
          <p className="text-xs text-slate-500">Map: © OpenStreetMap contributors (tiles load when your browser can reach OpenStreetMap; the markers work either way). Marker positions are approximate locality centres.</p>
        </div>
        <div className="lg:col-span-2"><LocalityPanel loc={loc} data={data} /></div>
      </div>
      <Disclaimer>Prices on this page are model estimates and dataset averages from a historic snapshot of Bengaluru property listings. They are not live market prices.</Disclaimer>
    </div>
  )
}
