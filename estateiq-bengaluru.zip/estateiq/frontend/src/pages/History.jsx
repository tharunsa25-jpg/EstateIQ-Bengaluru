import { useState } from 'react'
import { Eye, Trash2, Inbox } from 'lucide-react'
import { Link } from 'react-router-dom'
import { api } from '../api'
import { Async, Modal, PageHeader, useAsync, useToast, invalidate } from '../components/ui'
import { ResultDashboard } from '../components/ResultDashboard'
import { inr, num, dt } from '../lib/format'

export default function History() {
  const st = useAsync('history', api.historyList)
  const toast = useToast()
  const [sel, setSel] = useState(null)
  const del = async (id) => { try { await api.historyDelete(id); invalidate('history'); st.retry(); toast('Entry deleted') } catch (e) { toast(e.message, 'err') } }
  const clear = async () => { if (!window.confirm('Delete ALL saved predictions?')) return; try { await api.historyClear(); invalidate('history'); st.retry(); toast('History cleared') } catch (e) { toast(e.message, 'err') } }
  return (
    <>
      <PageHeader eyebrow="Prediction history" title="Your saved predictions">{api.mode === 'static' ? 'Stored in this browser (demo mode). With the Flask backend they are stored in SQLite.' : 'Saved in the backend SQLite database.'}</PageHeader>
      <Async state={st}>{(rows) => rows.length === 0 ? (
        <div className="glass grid place-items-center gap-3 p-14 text-center"><Inbox className="h-10 w-10 text-slate-500" /><p className="text-slate-300">No saved predictions yet.</p><Link to="/studio" className="btn-primary">Make a prediction</Link></div>
      ) : (
        <div className="space-y-4">
          <div className="flex justify-between"><p className="text-sm text-slate-400">{rows.length} saved</p><button className="btn-danger !py-2" onClick={clear}><Trash2 className="h-4 w-4" />Clear all</button></div>
          <div className="glass overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="border-b border-white/10 text-xs uppercase tracking-wider text-slate-400"><tr>{['Date & time', 'Locality', 'Area', 'BHK / Bath', 'Type', 'Predicted price', ''].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-white/5">{rows.map((r) => (
                <tr key={r.id} className="transition hover:bg-white/5">
                  <td className="px-4 py-3 text-slate-300">{dt(r.created_at)}</td><td className="px-4 py-3 text-white">{r.inputs.locality} <span className="text-xs text-slate-500">· {r.result.zone}</span></td><td className="px-4 py-3">{num(r.inputs.total_sqft)} sq.ft</td>
                  <td className="px-4 py-3">{r.inputs.bhk} / {r.inputs.bath}</td><td className="px-4 py-3">{r.inputs.property_type || '—'}</td><td className="px-4 py-3 font-display font-semibold text-cyan-200">{inr(r.result.price)}</td>
                  <td className="px-4 py-3"><div className="flex justify-end gap-2"><button className="btn-ghost !px-3 !py-1.5" onClick={() => setSel(r)}><Eye className="h-4 w-4" />View</button><button aria-label="Delete" className="btn-danger !px-3 !py-1.5" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></button></div></td>
                </tr>))}</tbody>
            </table>
          </div>
        </div>
      )}</Async>
      <Modal open={!!sel} onClose={() => setSel(null)} title={sel ? `Prediction · ${dt(sel.created_at)}` : ''}>{sel && <ResultDashboard result={sel.result} createdAt={sel.created_at} />}</Modal>
    </>
  )
}
