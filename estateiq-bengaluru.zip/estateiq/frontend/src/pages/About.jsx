import { ArrowRight, Users } from 'lucide-react'
import { PageHeader } from '../components/ui'

const Sec = ({ t, children }) => <section className="glass p-6"><h2 className="mb-3 font-display text-xl font-semibold text-white">{t}</h2><div className="space-y-2 text-sm leading-relaxed text-slate-300">{children}</div></section>
const List = ({ items }) => <ul className="list-disc space-y-1.5 pl-5">{items.map((i) => <li key={i}>{i}</li>)}</ul>

export default function About() {
  const arch = ['React + Tailwind UI', 'Flask REST API', 'Scikit-learn Pipeline (Joblib)', 'Bengaluru CSV dataset · SQLite history']
  return (
    <>
      <PageHeader eyebrow="About the project" title="Bengaluru Property Price Prediction Using Linear Regression">EstateIQ – Bengaluru Smart Property Price Prediction System. A Machine Learning academic mini project.</PageHeader>
      <div className="grid gap-5 lg:grid-cols-2">
        <Sec t="Problem statement"><p>Bengaluru property prices vary sharply by locality, size and configuration, which makes manual valuation slow, subjective and inconsistent. We need a data-driven, explainable way to estimate a Bengaluru property's price in ₹ from its attributes.</p></Sec>
        <Sec t="Project objectives"><List items={['Train a Multiple Linear Regression model on a genuine housing dataset.', 'Evaluate it honestly on unseen data (R², MAE, MSE, RMSE).', 'Serve predictions through a Flask API to a React interface.', 'Explain every prediction through feature contributions.', 'Visualise dataset patterns with interactive analytics.']} /></Sec>
        <Sec t="Existing system"><p>Traditional valuation relies on agents' experience or simple price-per-sqft rules of thumb. Online calculators are often opaque, may use random or hard-coded numbers, and rarely disclose their accuracy or data.</p></Sec>
        <Sec t="Proposed system"><p>A transparent ML platform: a scikit-learn pipeline (imputation → one-hot encoding → linear regression) trained with a leak-free train/test split, with metrics, coefficients and explanations all exposed in the interface.</p></Sec>
      </div>
      <div className="glass my-5 p-6"><h2 className="mb-4 font-display text-xl font-semibold text-white">System architecture</h2>
        <div className="flex flex-col items-stretch gap-3 md:flex-row md:items-center">{arch.map((a, i) => <div key={a} className="flex flex-1 items-center gap-3"><div className="flex-1 rounded-xl border border-cyan2/30 bg-gradient-to-br from-cyan2/10 to-violet2/10 p-4 text-center text-sm font-medium text-white">{a}</div>{i < arch.length - 1 && <ArrowRight className="hidden h-5 w-5 shrink-0 text-cyan2 md:block" />}</div>)}</div>
        <p className="mt-4 text-xs text-slate-400">Offline: <code className="text-cyan2">train_model.py</code> reads the CSV → trains → saves <code>model.joblib</code>, <code>metrics.json</code>, <code>analytics.json</code>. Online: the browser calls <code>/api/*</code> and Flask loads those artefacts.</p></div>
      <div className="grid gap-5 lg:grid-cols-2">
        <Sec t="Advantages"><List items={['Fully interpretable coefficients', 'Fast training and instant predictions', 'No fabricated numbers: every value comes from data or the trained model', 'Honest evaluation on held-out data']} /></Sec>
        <Sec t="Limitations"><List items={['Assumes linear, additive effects; misses curves and interactions', 'Errors are larger for expensive homes', 'Prices are LISTING (asking) prices from a historic snapshot, not transactions and not live market data', 'Floors, property age, parking and property type are not in the dataset, so they are recorded in reports but do not affect the price', 'MG Road, Peenya and Kadubeesanahalli have too few listings (under 15) and are not priced; localities with under 40 listings are flagged as limited data', 'Localities outside the 34 requested are grouped as "Other Bengaluru" for training',  'Predictions are estimates, not appraisals']} /></Sec>
        <Sec t="Future enhancements"><List items={['Log-price target, polynomial terms, Ridge/Lasso regularisation', 'Gradient boosting for comparison', 'A fresher Bengaluru dataset with property age, parking and property type, or a verified live data source', 'User accounts, map view, model retraining from the UI']} /></Sec>
        <Sec t="Technologies used"><div className="flex flex-wrap gap-2">{['React', 'Tailwind CSS', 'Recharts', 'Vite', 'Flask', 'Scikit-learn', 'Pandas', 'NumPy', 'Joblib', 'SQLite', 'Leaflet', 'OpenStreetMap', 'jsPDF'].map((t) => <span key={t} className="rounded-lg border border-white/15 bg-white/5 px-3 py-1 text-xs text-white">{t}</span>)}</div></Sec>
      </div>
      <div className="paper mt-5 p-6"><h2 className="mb-4 flex items-center gap-2 font-display text-xl font-semibold text-slate-900"><Users className="h-5 w-5 text-violet-600" />Team members</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{['Member 1', 'Member 2', 'Member 3', 'Guide / Mentor'].map((n, i) => <div key={n} className="rounded-xl border border-mist bg-white p-4 text-center"><div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-cyan2 to-violet2 font-display text-xl font-bold text-ink-950">{i + 1}</div><p className="font-semibold text-slate-900">{n}</p><p className="text-xs text-slate-500">Name · Roll No.</p></div>)}</div></div>
    </>
  )
}
