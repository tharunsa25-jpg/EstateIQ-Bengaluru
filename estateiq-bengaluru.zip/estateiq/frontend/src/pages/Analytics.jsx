import { useEffect, useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ComposedChart, Legend, Line, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis, ReferenceLine } from 'recharts'
import { TrendingUp, TrendingDown, IndianRupee } from 'lucide-react'
import { api } from '../api'
import { Async, ChartCard, Disclaimer, PageHeader, useAsync } from '../components/ui'
import { Tip, axisProps, gridProps } from '../components/charts'
import { C, ZONE_COLOR, inr, inrShort, inrSqft, num } from '../lib/format'

export default function Analytics() {
  const st = useAsync('analytics', api.analytics)
  return (
    <>
      <PageHeader eyebrow="Bengaluru locality analytics" title="Where Bengaluru prices differ">
        Charts are drawn from the Bengaluru listings dataset loaded by the backend ({st.data ? `${num(st.data.dataset.rows_used)} listings` : '…'}) and from the trained model. Estimates are for the dataset's median home so that localities compare fairly.
      </PageHeader>
      <Async state={st}>{(d) => <Dash d={d} />}</Async>
    </>
  )
}

function Dash({ d }) {
  const sup = useMemo(() => d.localities.filter((l) => l.supported), [d])
  const ref = d.dataset.reference_home
  const [mode, setMode] = useState('est')           // est = model estimate, listing = dataset average
  const [zone, setZone] = useState('All')
  const [loc, setLoc] = useState('Whitefield')
  const [bhk, setBhk] = useState(ref.bhk)
  const [curve, setCurve] = useState(null)
  const byName = (n) => d.localities.find((l) => l.name === n)
  const hi = byName(d.highlights.highest_est), lo = byName(d.highlights.lowest_est), hp = byName(d.highlights.highest_ppsf), lp = byName(d.highlights.lowest_ppsf)

  const rows = useMemo(() => sup.filter((l) => zone === 'All' || l.zone === zone)
    .map((l) => ({ ...l, price: mode === 'est' ? l.est_price : l.avg_price, ppsf: mode === 'est' ? l.est_ppsf : l.avg_ppsf })), [sup, mode, zone])
  const byPrice = [...rows].sort((a, b) => b.price - a.price), byPpsf = [...rows].sort((a, b) => b.ppsf - a.ppsf)
  const zoneRows = d.zones.map((z) => ({ ...z, name: z.zone }))

  useEffect(() => {
    setCurve(null)
    api.curve({ ...ref, bhk, bath: Math.max(1, Math.min(bhk, 4)), locality: loc }).then((r) => setCurve(r.points)).catch(() => setCurve([]))
  }, [loc, bhk]) // eslint-disable-line

  const chip = (active) => `rounded-lg px-3 py-1 text-xs transition ${active ? 'bg-cyan2/20 text-cyan2 ring-1 ring-cyan2/40' : 'bg-white/5 text-slate-400 hover:bg-white/10'}`
  const zoneLegend = <div className="flex flex-wrap gap-3 text-xs text-slate-300">{Object.entries(ZONE_COLOR).map(([z, c]) => <span key={z} className="inline-flex items-center gap-1.5"><i className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: c }} />{z}</span>)}</div>
  const hbar = (data, key, fmt, tick) => (
    <ResponsiveContainer><BarChart data={data} layout="vertical" margin={{ left: 6, right: 22 }}><CartesianGrid {...gridProps} horizontal={false} />
      <XAxis type="number" {...axisProps} tickFormatter={tick} /><YAxis type="category" dataKey="name" width={118} {...axisProps} interval={0} tick={{ fill: C.axis, fontSize: 10.5 }} />
      <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [['Locality', `${p.name} (${p.zone})`], [mode === 'est' ? 'Model estimate' : 'Avg listing', fmt(p[key])], ['Listings', num(p.n_listings)]]} />} />
      <Bar dataKey={key} radius={[0, 5, 5, 0]} barSize={12}>{data.map((r) => <Cell key={r.name} fill={ZONE_COLOR[r.zone]} />)}</Bar></BarChart></ResponsiveContainer>)

  const tile = (Icon, label, l, val, tone) => (
    <div className="glass p-5"><p className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-slate-400"><Icon className={`h-4 w-4 ${tone}`} />{label}</p>
      <p className="mt-2 font-display text-2xl font-bold text-white">{l.name}</p><p className="text-sm text-slate-400">{val}</p><p className="text-xs text-slate-500">{l.zone} · {l.n_listings} listings</p></div>)
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {tile(TrendingUp, 'Highest estimated value', hi, `${inr(hi.est_price)} · median-home estimate`, 'text-emerald-300')}
        {tile(TrendingDown, 'Lowest estimated value', lo, `${inr(lo.est_price)} · median-home estimate`, 'text-rose-300')}
        {tile(IndianRupee, 'Highest ₹/sq.ft (estimate)', hp, inrSqft(hp.est_ppsf), 'text-emerald-300')}
        {tile(IndianRupee, 'Lowest ₹/sq.ft (estimate)', lp, inrSqft(lp.est_ppsf), 'text-rose-300')}
      </div>
      <Disclaimer>{d.localities.filter((l) => !l.supported).map((l) => `${l.name} (${l.n_raw} listing${l.n_raw === 1 ? '' : 's'})`).join(', ')} {d.localities.some((l) => !l.supported) ? 'do not have enough listings in the dataset (minimum ' + d.dataset.min_rows_supported + ') and are excluded from price analytics rather than guessed.' : ''} Estimates use the dataset's median home ({num(ref.total_sqft)} sq.ft, {ref.bhk} BHK, {ref.bath} bath, {ref.balcony} balconies, ready to move). All figures come from a historic listing snapshot, not live prices.</Disclaimer>

      <div className="glass flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="flex flex-wrap items-center gap-2"><span className="text-xs uppercase tracking-wider text-slate-400">Show</span>
          <button className={chip(mode === 'est')} onClick={() => setMode('est')}>Model estimate (median home)</button><button className={chip(mode === 'listing')} onClick={() => setMode('listing')}>Average listing price (dataset)</button></div>
        <div className="flex flex-wrap items-center gap-2"><span className="text-xs uppercase tracking-wider text-slate-400">Zone</span>
          {['All', ...d.zones.map((z) => z.zone)].map((z) => <button key={z} className={chip(zone === z)} onClick={() => setZone(z)}>{z}</button>)}</div>
        {zoneLegend}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <ChartCard title="Locality vs average property price" sub={mode === 'est' ? 'Model-estimated price of the median home in each locality' : 'Average listing price in the dataset'} height={Math.max(300, byPrice.length * 24 + 40)}>{hbar(byPrice, 'price', inr, inrShort)}</ChartCard>
        <ChartCard title="Locality vs price per sq.ft (₹/sq.ft)" sub={mode === 'est' ? 'Model-estimated ₹/sq.ft for the median home' : 'Average listing ₹/sq.ft in the dataset'} height={Math.max(300, byPpsf.length * 24 + 40)}>{hbar(byPpsf, 'ppsf', inrSqft, (v) => `₹${num(v)}`)}</ChartCard>

        <ChartCard title="Zone-wise comparison: price" sub="North, South, East, West and Central Bengaluru (supported localities only)" height={300}>
          <ResponsiveContainer><BarChart data={zoneRows} margin={{ right: 10 }}><CartesianGrid {...gridProps} vertical={false} /><XAxis dataKey="name" {...axisProps} /><YAxis {...axisProps} tickFormatter={inrShort} width={64} /><Legend wrapperStyle={{ fontSize: 12, color: C.axis }} />
            <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [['Zone', p.name], ['Avg listing price', inr(p.avg_price)], ['Model est. (median home)', inr(p.est_price)], ['Localities / listings', `${p.n_localities} / ${num(p.n_listings)}`]]} />} />
            <Bar name="Avg listing price" dataKey="avg_price" fill={C.cyan} radius={[5, 5, 0, 0]} maxBarSize={34} /><Bar name="Model est. (median home)" dataKey="est_price" fill={C.violet} radius={[5, 5, 0, 0]} maxBarSize={34} /></BarChart></ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Zone-wise comparison: ₹/sq.ft" sub="Average listing ₹/sq.ft versus model estimate" height={300}>
          <ResponsiveContainer><BarChart data={zoneRows} margin={{ right: 10 }}><CartesianGrid {...gridProps} vertical={false} /><XAxis dataKey="name" {...axisProps} /><YAxis {...axisProps} tickFormatter={(v) => `₹${num(v)}`} width={64} /><Legend wrapperStyle={{ fontSize: 12, color: C.axis }} />
            <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [['Zone', p.name], ['Avg listing', inrSqft(p.avg_ppsf)], ['Model estimate', inrSqft(p.est_ppsf)]]} />} />
            <Bar name="Avg listing ₹/sq.ft" dataKey="avg_ppsf" fill={C.cyan} radius={[5, 5, 0, 0]} maxBarSize={34} /><Bar name="Model est. ₹/sq.ft" dataKey="est_ppsf" fill={C.violet} radius={[5, 5, 0, 0]} maxBarSize={34} /></BarChart></ResponsiveContainer>
        </ChartCard>

        <ChartCard className="lg:col-span-2" height={340} title="Property area vs predicted price" sub="Line = model prediction as area grows; dots = real listings from the selected locality.">
          <div className="-mt-9 mb-2 flex flex-wrap justify-end gap-3 text-xs">
            <label className="flex items-center gap-2 text-slate-400">Locality<select id="curve-loc" className="field !w-auto !py-1" value={loc} onChange={(e) => setLoc(e.target.value)}>{sup.map((l) => <option key={l.name}>{l.name}</option>)}</select></label>
            <label className="flex items-center gap-2 text-slate-400">BHK<select id="curve-bhk" className="field !w-auto !py-1" value={bhk} onChange={(e) => setBhk(Number(e.target.value))}>{[1, 2, 3, 4, 5].map((b) => <option key={b}>{b}</option>)}</select></label>
          </div>
          <ResponsiveContainer height="88%">
            {curve === null ? <div /> : <ComposedChart margin={{ right: 12, bottom: 16 }}><CartesianGrid {...gridProps} /><XAxis type="number" dataKey="x" domain={[400, 4000]} {...axisProps} tickFormatter={num} label={{ value: 'Property area (sq.ft)', position: 'insideBottom', offset: -10, fill: C.axis, fontSize: 11 }} />
              <YAxis type="number" dataKey="y" {...axisProps} tickFormatter={inrShort} width={64} domain={[0, 'auto']} allowDataOverflow /><ZAxis range={[26, 26]} />
              <Tooltip content={<Tip rows={(p) => [['Area', `${num(p.x)} sq.ft`], ['Price', inr(p.y)]]} />} />
              <Scatter name="Listings" data={(d.locality_points[loc] || []).filter((p) => p.x <= 4000)} fill={C.violet} fillOpacity={0.55} />
              <Line name="Model prediction" data={curve} dataKey="y" stroke={C.cyan} strokeWidth={3} dot={false} isAnimationActive={false} /></ComposedChart>}
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Area vs listing price (all Bengaluru)" sub="Each dot is one listing (sample)." height={300}>
          <ResponsiveContainer><ScatterChart margin={{ right: 12, bottom: 16 }}><CartesianGrid {...gridProps} /><XAxis type="number" dataKey="x" {...axisProps} tickFormatter={num} label={{ value: 'Area (sq.ft)', position: 'insideBottom', offset: -10, fill: C.axis, fontSize: 11 }} /><YAxis type="number" dataKey="y" {...axisProps} tickFormatter={inrShort} width={64} /><ZAxis range={[26, 26]} />
            <Tooltip content={<Tip rows={(p) => [['Area', `${num(p.x)} sq.ft`], ['Price', inr(p.y)]]} />} /><Scatter data={d.scatter_area_price} fill={C.cyan} fillOpacity={0.5} /></ScatterChart></ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Bedrooms (BHK) vs average listing price" height={300}>
          <ResponsiveContainer><BarChart data={d.bhk_avg} margin={{ right: 12 }}><CartesianGrid {...gridProps} vertical={false} /><XAxis dataKey="bhk" {...axisProps} tickFormatter={(v) => `${v} BHK`} /><YAxis {...axisProps} tickFormatter={inrShort} width={64} />
            <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [['BHK', p.bhk], ['Average price', inr(p.avg)], ['Listings', num(p.count)]]} />} /><Bar dataKey="avg" fill={C.cyan} radius={[6, 6, 0, 0]} maxBarSize={44} /></BarChart></ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Area basis vs average listing price" sub="Super built-up, built-up, plot and carpet area listings" height={300}>
          <ResponsiveContainer><BarChart data={d.area_type_avg} margin={{ right: 12 }}><CartesianGrid {...gridProps} vertical={false} /><XAxis dataKey="type" {...axisProps} tickFormatter={(v) => v.replace(' Area', '')} /><YAxis {...axisProps} tickFormatter={inrShort} width={64} />
            <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [['Area basis', p.type], ['Average price', inr(p.avg)], ['Listings', num(p.count)]]} />} /><Bar dataKey="avg" fill={C.violet} radius={[6, 6, 0, 0]} maxBarSize={52} /></BarChart></ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Price distribution" sub="Listings per ₹10 lakh band (last bar = ₹2 crore and above)." height={300}>
          <ResponsiveContainer><BarChart data={d.histogram} barCategoryGap={2} margin={{ right: 12 }}><CartesianGrid {...gridProps} vertical={false} /><XAxis dataKey="bin" {...axisProps} interval={3} /><YAxis {...axisProps} tickFormatter={num} width={48} />
            <Tooltip cursor={{ fill: 'rgba(255,255,255,.04)' }} content={<Tip rows={(p) => [['Price band', p.range], ['Listings', num(p.count)]]} />} /><Bar dataKey="count" fill={C.cyan} radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
