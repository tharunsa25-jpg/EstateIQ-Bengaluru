// Copies model artefacts produced by backend/train_model.py into src/static-data (used by the no-server demo build)
import fs from 'node:fs'
const src = new URL('../../backend/model/', import.meta.url)
for (const f of ['model_params.json', 'analytics.json']) fs.copyFileSync(new URL(f, src), new URL(`../src/static-data/${f}`, import.meta.url))
console.log('static data synced')
